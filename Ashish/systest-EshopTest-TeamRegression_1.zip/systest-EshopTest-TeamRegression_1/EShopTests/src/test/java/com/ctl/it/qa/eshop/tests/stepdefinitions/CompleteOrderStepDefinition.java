package com.ctl.it.qa.eshop.tests.stepdefinitions;

import com.ctl.it.qa.eshop.tools.steps.CompleteTomBillingOrderSteps;
import com.ctl.it.qa.eshop.tools.steps.FFWFCompleteOrderSteps;
import cucumber.api.java.en.Then;
import net.thucydides.core.annotations.Steps;

public class CompleteOrderStepDefinition {
	/*
	 * Not in Use Now the Commented ones Below
	 */
	@Steps
	CompleteTomBillingOrderSteps completeordersteps;
	@Steps
	FFWFCompleteOrderSteps ffwfcompleteordersteps;
	
	@Then("^I Should Complete the Backend Tasks FFWF TOM and Billing as Completed$")
	public void i_Should_Complete_the_Backend_Tasks_FFWF_TOM_and_Billing_as_Completed() {
	   
		//ffwfcompleteordersteps.FFWFTaskCompleteManager();
//		ffwfcompleteordersteps.FFWFTaskCompleteManager2();
//		completeordersteps.Complete_TOM_and_Billing_Tasks();
		
	}
	
	@Then("^I wake up remote computer to be ready to complete websop tasks as a precaution step$")
	public void i_wake_up_remote_computer_to_be_ready_to_complete_websop_tasks_as_a_precaution_step() {
		//completeordersteps.wake_up_remote_computer();
	}
	
	@Then("^I check for the billing Status as Success$")
	public void billing_Status_Check() {
		//completeordersteps.checkBillingStatus();
	}
	
	
	@Then("^I complete the disconnected FFWF order if it is avaialble for Disconnection$")
	public void FFWF_Disconnected() {
		//ffwfcompleteordersteps.FFWFTaskDisconnectManager();		
	}
	
	
	/*
	 * 
	 * Complete Order Web Tool Code - Nitish
	 */
	@Then("^I check for the billing Status as Success in MongoDB$")
	public void i_check_for_the_billing_Status_as_Success_in_MongoDB() {
		ffwfcompleteordersteps.check_for_the_billing_Status_as_Success_in_MongoDB();
	}
}
