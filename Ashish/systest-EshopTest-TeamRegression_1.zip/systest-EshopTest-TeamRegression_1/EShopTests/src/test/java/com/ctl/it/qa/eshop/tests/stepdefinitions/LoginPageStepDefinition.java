package com.ctl.it.qa.eshop.tests.stepdefinitions;

import java.io.IOException;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;

import com.ctl.it.qa.eshop.tools.steps.LoginSteps;
import com.ctl.it.qa.eshop.tools.steps.OrderValidationSteps;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import net.serenitybdd.core.Serenity;
import net.thucydides.core.annotations.Steps;

public class LoginPageStepDefinition {

	@Steps
	LoginSteps loginSteps;
	@Steps
	OrderValidationSteps orderValidationSteps;


	@Given("^I validate the Account Status of the listed orders in SFC$")
	public void I_validate_the_Account_Status_of_the_listed_orders_in_SFC() throws EncryptedDocumentException, InvalidFormatException, IOException{
		orderValidationSteps.validateOrderStatusInSFC();
	}


	@Given("^I validate the list of orders$")
	public void I_validate_the_list_of_orders() throws EncryptedDocumentException, InvalidFormatException, IOException{
		//		orderValidationSteps.validateOrderStatus();
	}

	@Given("^I complete the listed FFWF orders$")
	public void I_complete_the_listed_FFWF_orders() throws EncryptedDocumentException, InvalidFormatException, IOException{
		//		orderValidationSteps.completeFFWF();
		//		orderValidationSteps.completeTOM();
	}

	@Given("^I complete the listed Actions$")
	public void I_complete_the_listed_Actions() throws EncryptedDocumentException, InvalidFormatException, IOException{
		orderValidationSteps.readAction();
	}

	@Given("^I set the order number and calculated new due date$")
	public void I_calculate_the_new_due_date() throws EncryptedDocumentException, InvalidFormatException, IOException{
		orderValidationSteps.getOrderDetails();
	}
	
	
	@Then("^I initiate the Vacation Suspend flow$")
	public void I_initiate_VacSus() throws EncryptedDocumentException, InvalidFormatException, IOException{
		orderValidationSteps.initOrderVacSus(Serenity.sessionVariableCalled("orderNum"),Serenity.sessionVariableCalled("calculatedNewDate"));
	}

	@Given("^I should be on Eshop login screen$")
	public void i_should_be_on_Eshop_login_screen() {

		loginSteps.Eshop_url_OpenPage();

	}

	@When("^I enter username and password$")
	public void i_enter_username_and_password1() throws Throwable {

		loginSteps.loginToEshop();

	}

	@Then("^I perform cleanup of open accounts$")
	public void I_perform_cleanup_of_open_accounts() throws Throwable {
		loginSteps.cleanOpenAccounts();
	}

	//ac31339 Code starts

	@Given("^I should be on SFC login screen$")
	public void i_should_be_on_SFC_login_screen() {
		loginSteps.Sfc_url_OpenPage();
	}

	//ac31339 code ends
}