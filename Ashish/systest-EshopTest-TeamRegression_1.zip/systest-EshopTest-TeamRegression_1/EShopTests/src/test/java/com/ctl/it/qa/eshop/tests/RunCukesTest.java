package com.ctl.it.qa.eshop.tests;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.runner.RunWith;
import com.ctl.it.qa.staf.Environment;
import com.ctl.it.qa.staf.HtmlReport;
import com.ctl.it.qa.staf.STAFEnvironment;
import com.ctl.it.qa.staf.Steps;
import com.ctl.it.qa.staf.TestEnvironment;
import cucumber.api.CucumberOptions;
import net.serenitybdd.cucumber.CucumberWithSerenity;

@TestEnvironment(Environment.TEST1)
@RunWith(CucumberWithSerenity.class)
@CucumberOptions(features = "src/test/resources/features/Regression", plugin = { "pretty", "json:target/Reports/EShopCucumberReport.json" ,"html:target/Reports/EShopHTMLReport" },
dryRun=false,tags = { "@hsiandpots" })
//dryRun=false,tags = { "@readAction" }) 
// A few other tags: @EshopTestScripts @EShopSanity @EShopFunctional @eshopcentral
//, glue= {"com.ctl.it.qa.eshop.tests.stepdefinitions"}
public class RunCukesTest {

	@BeforeClass
	public static void setEnvironment() {
		STAFEnvironment.registerEnvironment(RunCukesTest.class);
		Steps.initialize("EShopLogin.xml");
	}

	@AfterClass
	public static void test() throws Exception {
		HtmlReport.generate();
	}
}
