package com.ctl.it.qa.eshop.tests.stepdefinitions;


import com.ctl.it.qa.eshop.tools.steps.NonPaySuspendSteps;


import cucumber.api.java.en.Then;
import net.thucydides.core.annotations.Steps;

public class NonpayVacationSuspendStepDefinition {

	@Steps
	NonPaySuspendSteps nonpayVacationSuspendUser;

	@Then("^I click on suspend all button$")
	public void i_click_on_Nonpay_Suspend() throws Exception {
		nonpayVacationSuspendUser.select_NonpaySuspend_Service();
	}
	
	@Then ("^I click on nonpay suspend submit button$")
	public void i_click_on_nonpay_suspend_submit_button() {
		nonpayVacationSuspendUser.select_NonpaySuspend_Submit_button();
	}
	
	@Then("^I click on nonpay suspend submit updates button$")
	public void i_click_on_Nonpay_Suspend_Submit_Update_button() throws Exception {
		nonpayVacationSuspendUser.select_NonpaySuspend_Submit_Update();
	}
}



