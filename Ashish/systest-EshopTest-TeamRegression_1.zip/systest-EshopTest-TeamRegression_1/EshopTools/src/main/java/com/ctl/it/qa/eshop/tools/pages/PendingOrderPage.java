package com.ctl.it.qa.eshop.tools.pages;

import com.ctl.it.qa.staf.Page;

import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.WebElementFacade;

public class PendingOrderPage extends Page {

	@FindBy(xpath = "//button[contains(text(),'Scheduling')]")
	public WebElementFacade scheduling;

	// Nitish Cancel order SUP1

	/*
	 * @FindBy(
	 * xpath="//select[@class='form-control drop-down-arrangement etf-fee-text ng-pristine ng-valid ng-touched']"
	 * ) public WebElementFacade cancel_reason;
	 */

	@FindBy(xpath = "(//a//div[@class='btn btn-secondary'])")
	public WebElementFacade other_actions_box;

	@FindBy(xpath = "//a[contains(text(),'Cancel Order')]")
	public WebElementFacade cancel_order;

	@FindBy(xpath = ".//a[contains(.,'Place on Hold')]")
	public WebElementFacade hold_order;

	@FindBy(xpath = ".//label[contains(.,'On Hold reason')]/../select")
	public WebElementFacade hold_reason;

	@FindBy(xpath = "//select[@class='form-control drop-down-arrangement etf-fee-text ng-untouched ng-pristine ng-valid']")
	public WebElementFacade cancel_reason;

	@FindBy(xpath = "(//button[@class='btn btn-primary'])[1]")
	public WebElementFacade continue_cancel_order;

	@FindBy(xpath = "(//div[@class='btn btn-green'])[1]")
	public WebElementFacade other_actions;

	@FindBy(xpath = "//button[contains(text(),'Cancel Order')]")
	public WebElementFacade cancel_order_button;

	@FindBy(xpath = ".//button[contains(.,'Place on Hold')]")
	public WebElementFacade hold_order_button;

	@FindBy(xpath = "//button[text()='Submit']")
	public WebElementFacade submit_order_button;
	
	@FindBy(xpath = "//label[text()='Order Remark']/../input[@name='rbtnOrderTechRemarks']")
	public WebElementFacade order_remarks_radio_button;
	
	@FindBy(xpath = "//div/textarea[@title=\"Order/Tech Remarks\"]")
	public WebElementFacade order_tech_remarks_text;
	
	@FindBy(xpath = "//label[text()='Tech Remark ']/../input[@name='rbtnOrderTechRemarks']")
	public WebElementFacade tech_remarks;

	public WebElementFacade getUniqueElementInPage() {

		return other_actions_box;
	}

}
