package com.ctl.it.qa.eshop.tools.steps;

import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.ElementNotInteractableException;
import org.openqa.selenium.ElementNotVisibleException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.ctl.it.qa.eshop.tools.pages.CustomerDetailsPage;
import com.ctl.it.qa.eshop.tools.pages.OrderSummaryPage;
import com.ctl.it.qa.staf.Steps;

import net.serenitybdd.core.Serenity;
import net.serenitybdd.core.pages.WebElementFacade;
import net.thucydides.core.annotations.Step;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

@SuppressWarnings("unused")
public class CustomerDetailsSteps extends Steps {

	private final Logger slf4jLogger = LoggerFactory.getLogger(CustomerDetailsSteps.class);

	CustomerDetailsPage customerDetailsPage;
	@Step
	public void searchAccount(String env, String first, String last, String phone, String address) {
		customerDetailsPage.shouldExist(customerDetailsPage,60);
		customerDetailsPage.firstNam.type(first);
		customerDetailsPage.lastNam.sendKeys(last);
		customerDetailsPage.phoneNum.sendKeys(phone);
		customerDetailsPage.showAddress.sendKeys(address);
		slf4jLogger.info("Entered the following Customer details for Env=" + env + ": firstName=" + first + ", lastName=" + last + " ,PhoneNumber=" + phone + " and address=" + address);

	}

	@Step
	public void letsGoButton() {
		waitABit(1000);
		customerDetailsPage.LetsGoButton.click();
//		waitABitForSpinner();
		slf4jLogger.info("clicked on to 'Let's Go' button");
//		waitABit(60000);
		waitABit(10000);

	}
	
	
	public void waitABitForSpinner() {
		int counter=0;
		System.out.println("Spinning started");
		customerDetailsPage.lbl_spinner.waitUntilNotVisible();
		/*while(getDriver().findElement(By.xpath(".//img[contains(@id,'interstitial-image')]")).isEnabled())
		{
			waitABit(1000);
			counter=counter++;
		}
		System.out.println("Spinning ended in "+counter+" seconds.");*/
		System.out.println("Spinning ended");
		waitABit(2000);
	}


	@Step
	public void noMatchFoundText() {
		customerDetailsPage.noMatchFoudText.waitUntilVisible();
		WaitForPageToLoad(10);
		slf4jLogger.info("address no match text validation");
		waitABit(5000);
		boolean flag = customerDetailsPage.noMatchFoudText.getText().contains("No Results Found");
		Assert.assertTrue(flag);
	}

	@Step
	public void checkNumOfAddress() {
		List<WebElement> ele = getDriver()
				.findElements(By.xpath("//input[@id='optionsRadiosAll']/following-sibling::span[1]"));
		slf4jLogger.info("num of address =" + ele.size());
		for (int i = 0; i < ele.size(); i++) {

			slf4jLogger.info(ele.get(i).getText());
		}
	}


	@Step
	public void enterAddressdetails(String street, String unit, String city, String state, String zip) {

		customerDetailsPage.shouldExist(customerDetailsPage, 60);
		customerDetailsPage.showalladdress.click();
		customerDetailsPage.street.type(street);
		customerDetailsPage.unit.type(unit);
		customerDetailsPage.city.type(city);
		customerDetailsPage.zipcode.type(zip);
		customerDetailsPage.state.selectByValue(state);
		slf4jLogger.info("Entered the following Address details for Street=" + street + ", Unit=" + unit + ", City="
				+ city + " ,State=" + state + " ,Zipcode=" + zip);
		waitABit(5000);
	}

	@Step
	public void searchAccoundetails(String env, String first, String last, String phone) {
		customerDetailsPage.shouldExist(customerDetailsPage, 60);
		customerDetailsPage.firstNam.type(first);
		customerDetailsPage.lastNam.type(last);
		customerDetailsPage.phoneNum.type(phone);
		slf4jLogger.info("Entered the following Customer details for Env=" + env + ": firstName=" + first
				+ ", lastName=" + last + " ,PhoneNumber=" + phone);

	}

	@Step
	public void selectMatchAddress() {
		customerDetailsPage.selectradiobtn.click();
		slf4jLogger.info("clicked on radio button and select addresss");
		customerDetailsPage.continuebtn.click();
		slf4jLogger.info("clicked on continue button");

	}

	//Nitish 

	@Step
	public void i_click_on_Account_or_Order_already_exists_link() {
		customerDetailsPage.shouldExist(customerDetailsPage,60);
		customerDetailsPage.orderexists.click();
		slf4jLogger.info("clicked on Account or Order already exists link");
		customerDetailsPage.shouldBeVisible(customerDetailsPage.newcustomer);
		slf4jLogger.info("Start New Customer Order is visible");

	}

	//Nitish MACD Completed Account Number as Input
	@Step
	public void enter_completed_account_number(String completed_accountnum) {

		customerDetailsPage.accnumrbn.click();
		customerDetailsPage.existsaaccnumr.sendKeys(completed_accountnum);
		slf4jLogger.info("Entered completed account number");

	}

	/*
	 * Code Updated with SFC Lightning Version - Nitish
	 */

	@Step
	public void click_create_new_account() {
		waitABit(25000);
		try{
			getDriver().findElement(By.xpath("(//button[@title=\"Close\"])[2]")).click();
		}
		catch(Exception e) {}
		/*boolean Tab = false;
		try {
			Tab=getDriver().findElement(By.xpath("(//span[@class='title slds-truncate'])[1]")).isDisplayed();
		}
		catch(Exception e){
			System.out.println(e);
		}
		if(Tab) {
			System.out.println("Tab ");

			try {
				// case1
				getDriver().findElement(By.xpath("(//span[@class='title slds-truncate'])[2]")).click();
				waitABit(2000);
				SFC_AlertHandling();
				waitABit(2000);
				WebElement IL=getDriver().findElement(By.xpath("//span[contains(text(),'Interaction Log')]"));
				JavascriptExecutor js = (JavascriptExecutor) getDriver();
				js.executeScript("arguments[0].scrollIntoView();", IL);
				waitABit(5000);
				getDriver().findElement(By.xpath("//input[@name='Call_Disposition_Reason__c']")).click();
				waitABit(2000);
				getDriver().findElement(By.xpath("//*[@data-value='HSI']")).click();
				waitABit(2000);
				getDriver().findElement(By.xpath("//*[@class='slds-textarea']")).sendKeys("Closed");
				waitABit(5000);
				getDriver().findElement(By.xpath("//button[@type='submit']")).click();
				waitABit(2000);
				getDriver().findElement(By.xpath("//button[@title='Close Tab']")).click();
				waitABit(5000);
				// case2
				//				getDriver().findElement(By.xpath("(//span[@class='title slds-truncate'])[1]")).click();
				//				SFC_AlertHandling();
				//				waitABit(2000);
				//				WebElement IL=getDriver().findElement(By.xpath("//span[contains(text(),'Interaction Log')]"));
				//				JavascriptExecutor js = (JavascriptExecutor) getDriver();
				//				js.executeScript("arguments[0].scrollIntoView();", IL);
				//				waitABit(5000);
				//				getDriver().findElement(By.xpath("//input[@name='Call_Disposition_Reason__c']")).click();
				//				waitABit(2000);
				//				getDriver().findElement(By.xpath("//*[@data-value='HSI']")).click();
				//				waitABit(2000);
				//				getDriver().findElement(By.xpath("//*[@class='slds-textarea']")).sendKeys("Closed");
				//				waitABit(5000);
				//				getDriver().findElement(By.xpath("//button[@type='submit']")).click();
				//				waitABit(2000);
				//				getDriver().findElement(By.xpath("//button[@title='Close Tab']")).click();
				//				waitABit(5000);
			}catch(Exception e) {
				System.out.println("Catch exection in TAB"+e);
			}

		}


		System.out.println("Out of While Alert condition Block");*/
		waitABit(10000);
/*		customerDetailsPage.btn_account.click();
		slf4jLogger.info("Clicked Account Button on SFC Lightning Version");*/
		WebElement element = getDriver().findElement(By.xpath("//span[contains(text(),'Accounts')]"));
		JavascriptExecutor executor = (JavascriptExecutor) getDriver();
		executor.executeScript("arguments[0].click();", element);
		waitABit(5000);
		WebElement element2 = getDriver().findElement(By.xpath("//div[@title='New']"));
		JavascriptExecutor executor2 = (JavascriptExecutor) getDriver();
		executor.executeScript("arguments[0].click();", element2);
//		customerDetailsPage.btn_createnew.click();
		slf4jLogger.info("Clicked New Button on SFC Lightning Version");

	}

	/*
	 * Code Updated with SFC Lightning Version - Nitish
	 */
	@Step
	public void create_new_account(String firstName, String lastName, String contactNum,String email, String address)
	{
		waitABit(10000);
		customerDetailsPage.tbx_account_first_name.sendKeys(firstName);
		customerDetailsPage.tbx_account_last_name.sendKeys(lastName);
		customerDetailsPage.tbx_phone_number.sendKeys(contactNum);
		customerDetailsPage.tbx_Email.sendKeys(contactNum);
		customerDetailsPage.tbx_address_field.sendKeys(address);
		slf4jLogger.info("Entered the following Customer details for firstName=" + firstName + " lastName=" + lastName + " PhoneNumber=" + contactNum + " Email id=" + email+" and address=" + address);
		waitABit(20000);
		WebElement SelectAddress=getDriver().findElement(By.xpath("//*[@value='"+address+"']"));
		Actions actions = new Actions(getDriver());
		actions.moveToElement(SelectAddress);
		actions.click().build().perform();
		slf4jLogger.info("Selected the Address "+address);

	}

	/*
	 * Code Updated with SFC Lightning Version - Nitish
	 */
	@Step
	public void create_new_account(String firstName, String lastName, String contactNum, String address)
	{
		waitABit(20000);
		customerDetailsPage.tbx_account_first_name.sendKeys(firstName);
		customerDetailsPage.tbx_account_last_name.sendKeys(lastName);
		customerDetailsPage.tbx_smb_account_name.sendKeys("SMB Account");
		customerDetailsPage.tbx_smb_primary_contact.sendKeys("4444444444");
		customerDetailsPage.tbx_smb_business_phone_num.sendKeys("3333333333");
		customerDetailsPage.tbx_smb_email.sendKeys("Akash.Ranjan@lumen.com");
		customerDetailsPage.tbx_address_smb_field.sendKeys(address);
		slf4jLogger.info("Entered the following Customer details for firstName=" + firstName + ", lastName=" + lastName + " ,PhoneNumber=" + contactNum + " and address=" + address);

		System.out.println("Now  Performing....");
		waitABit(20000);
		System.out.println("//*[contains(@value,'"+address+"')]");
		WebElement element = getDriver().findElement(By.xpath("//*[contains(@value,'"+address+"')]"));
		JavascriptExecutor executor = (JavascriptExecutor) getDriver();
		executor.executeScript("arguments[0].click();", element);
		slf4jLogger.info("Selected the Address "+address);
	}

	/*
	 * Code Updated with SFC Lightning Version - Nitish
	 */
	@Step
	public void validate_address(){
		waitABit(2000);
		customerDetailsPage.ownorrent.click();
		waitABit(2000);
		customerDetailsPage.select_own_house.click();
		slf4jLogger.info("selected Own Option");	
		waitABit(3000);
		JavascriptExecutor js = (JavascriptExecutor) getDriver();
		js.executeScript("arguments[0].scrollIntoView();", customerDetailsPage.btn_validate_address);
		customerDetailsPage.btn_validate_address.click();  
		slf4jLogger.info("Clicked Validate Address Button");
		waitABit(7000);
		customerDetailsPage.btn_save.click();
		slf4jLogger.info("Clicked Save Button");
	}      

	
	@Step
	public void validate_smb_address(){
		JavascriptExecutor js = (JavascriptExecutor) getDriver();
		js.executeScript("arguments[0].scrollIntoView();", customerDetailsPage.btn_validate_address);
		customerDetailsPage.btn_validate_address.click();  
		slf4jLogger.info("Clicked Validate Address Button");
		waitABit(7000);
		customerDetailsPage.btn_save.click();
		slf4jLogger.info("Clicked Save Button");
	}      

	
	/*
	 * Code Updated with SFC Lightning Version - Nitish
	 */
	@Step
	public void click_order_eshop() {
		waitABit(30000);
		WebElement element = getDriver().findElement(By.xpath("(//button[contains(text(),'Modify')]/../button)[1]"));
		JavascriptExecutor executor = (JavascriptExecutor) getDriver();
		executor.executeScript("arguments[0].click();", element);
		waitABit(10000);
		ArrayList<String> tabs2 = new ArrayList<String> (getDriver().getWindowHandles());
		getDriver().switchTo().window(tabs2.get(1));
		
		WebElement element2 = getDriver().findElement(By.xpath("//input[@value='Launch Order System']"));
		JavascriptExecutor executor2 = (JavascriptExecutor) getDriver();
		executor.executeScript("arguments[0].click();", element2);
		waitABit(10000);
		
		
		
		/*List<WebElement> e=getDriver().findElements(By.xpath("//button[contains(text(),'Order (eShop)')]"));
		int a=e.size();
		int i=1;
		System.out.println(e.size());
		while(i<=a) {
			try {
				WebElement e1=getDriver().findElement(By.xpath("(//button[contains(text(),'Order (eShop)')])["+i+"]"));
				System.out.println(e1.getLocation().getX());
				System.out.println(e1.getLocation().getY());
				System.out.println(i);
				//if(i==1){
				i++;
				e1.click();	
				//				JavascriptExecutor js = (JavascriptExecutor) getDriver();
				//				js.executeScript("arguments[0].scrollIntoView();", e1);
				//				JavascriptExecutor js1 = (JavascriptExecutor) getDriver();
				//				js1.executeScript("arguments[0].click();", e1);
				//				break;
				//}
			}
			catch(Exception ex){
				System.out.println("Excetion caught :"+ex);
			}
		}	
		slf4jLogger.info("Clicked Order Eshop Button");	
		Set<String> allWindows=getDriver().getWindowHandles();
		Iterator<String> windowIterator=allWindows.iterator();
		String parentWindow=windowIterator.next();
		String childWindow=windowIterator.next();
		getDriver().switchTo().window(childWindow);
		getDriver().manage().window().maximize();*/		
		slf4jLogger.info("Launched Eshop Application and New URL is  "+getDriver().getCurrentUrl());	
	}

	/**
	 * Method to enter ORN which was captured after the order is put on hold
	 */
	public void  enter_ORN_For_Order_On_Hold(){
		try {
			customerDetailsPage.txt_Existing_Information_Order_Number.sendKeys(AccountInformationSteps.ORN);
			slf4jLogger.info("ORN for order in hold is entered, which is  --------" + AccountInformationSteps.ORN);
		} catch (Exception e) {
			Assert.fail("ORN for order in hold could not be entered. Please check if UI is changed or applicaion is down");
			e.printStackTrace();
		}
	}

	/**
	 * Step to enter ORN which was captured after the order is put on hold
	 */
	@Step
	public void enters_ORN_On_Hold() {
		enter_ORN_For_Order_On_Hold();
		slf4jLogger.info("ORN for order in hold step is completed");
	}

	/**
	 * Step to click on the Acount/order already exists link
	 */
	@Step
	public void i_click_on_Account_or_Order_already_exists() {
		customerDetailsPage.orderexists.click();
		slf4jLogger.info("clicked on Account or Order already exists link");
	}

	/**
	 * Method to click on Lets go button
	 */
	public void click_On_Lets_Go_Button(){
		try {
			customerDetailsPage.btn_Lets_Go.click();
			slf4jLogger.info("Lets Go button Clicked after entering details");
		} catch (Exception e) {
			Assert.fail("Lets Go button is not Clicked after entering details. Please check if UI is changed or applicaion is down");
			e.printStackTrace();
		}
	}

	/**
	 * Method to enter first name in ESHOP screen
	 */
	public void enter_First_Name_ESHOP(String firstName){
		try {
			customerDetailsPage.txt_First_Name_ESHOP.sendKeys(firstName);
			slf4jLogger.info("First name entered in EHOP screen, which is ------" + firstName);
		} catch (Exception e) {
			Assert.fail("First name is not entered in EHOP screen. Please check if UI is changed or applicaion is down");
			e.printStackTrace();
		}
	}

	/**
	 * Method to enter last name in ESHOP screen
	 */
	public void enter_Last_Name_ESHOP(String lastName){
		try {
			customerDetailsPage.txt_Last_Name_ESHOP.sendKeys(lastName);
			slf4jLogger.info("Last name entered in EHOP screen, which is ------" + lastName);
		} catch (Exception e) {
			Assert.fail("Last name is not entered in EHOP screen. Please check if UI is changed or applicaion is down");
			e.printStackTrace();
		}
	}

	/**
	 * Method to enter Contact Number in ESHOP screen
	 */
	public void enter_Contact_Number_ESHOP(String contactNumber){
		try {
			customerDetailsPage.txt_Contact_Number_ESHOP.sendKeys(contactNumber);
			slf4jLogger.info("Contact Number is entered in EHOP screen, which is ------" + contactNumber);
		} catch (Exception e) {
			Assert.fail("Contact Number is not entered in EHOP screen. Please check if UI is changed or applicaion is down");
			e.printStackTrace();
		}
	}

	/**
	 * Step to enter Customer Information in ESHOP Screen
	 */
	@Step
	public void enters_Customer_Information(String firstName, String lastName, String contactNumber) {
		enter_First_Name_ESHOP(firstName);
		enter_Last_Name_ESHOP(lastName);
		enter_Contact_Number_ESHOP(contactNumber);
	}

	/**
	 * Step to click on Lets Go button in ESHOP Customer information screen
	 */
	@Step
	public void clicks_On_Lets_Go_Button() {
		click_On_Lets_Go_Button();
	}

	/**
	 * Step to create a New account with email address from SFC application
	 * @param firstName
	 * @param lastName
	 * @param contactNum
	 * @param address
	 */
	@Step
	public void create_New_Account_With_Email_From_SFC(String firstName, String lastName, String contactNum, String address, String email)
	{
		int iframes_Count =getDriver().findElements(By.tagName("iframe")).size();
		System.out.println("Frames Count for Account creation  "+iframes_Count);
		WebElement frameElement=getDriver().findElement(By.xpath("//iframe[contains(@src,'ServiceAddressCreation')]"));
		//iframe[@id='ext-comp-1050']
		if(frameElement.isDisplayed()){
			String frameName=frameElement.getAttribute("name");
			System.out.println("Account creation Frame name is  "  +frameName);
			getDriver().switchTo().frame(frameName);
			WebDriverWait wait = new WebDriverWait(getDriver(),30);
			wait.until(ExpectedConditions.visibilityOf(customerDetailsPage.address_avail_flag));
			customerDetailsPage.tbx_account_first_name.sendKeys(firstName);
			System.out.println("Entered First Name and ALL Looks Good");
			slf4jLogger.info("FirstName added ------" + firstName);
			customerDetailsPage.tbx_account_last_name.sendKeys(lastName);
			slf4jLogger.info("LastName added ------" + lastName);
			customerDetailsPage.tbx_phone_number.sendKeys(contactNum);
			slf4jLogger.info("Phone Number added ------" + contactNum);
			customerDetailsPage.txt_Email.sendKeys(email);
			slf4jLogger.info("Email added ------" + email);
			customerDetailsPage.tbx_address_field.type(address);
			slf4jLogger.info("Address added ------" + address);
			waitABit(1000);

		}else{
			System.out.println("Frame is Not Available");
			slf4jLogger.info("Frame is Not Available");
		}

		String expected_address=address.trim();
		List<WebElement> ss = getDriver().findElements(By.xpath("//*[@id='suggestions']/option"));
		WebElement input_address = getDriver().findElement(By.xpath("//input[@id='oneLineAddressField']"));
		if (ss.size() > 0) {
			try {
				//input_address.clear();
				List<WebElement> address_collections = getDriver().findElements(By.xpath("//*[@data-geoaddressid]"));
				for(int i=0;i<address_collections.size();i++) {
					String actualTxt =address_collections.get(i).getAttribute("value");
					System.out.println("Actual address "+ actualTxt);
					if(actualTxt.contains(expected_address)) {
						waitABit(1000);
						Actions action = new Actions(getDriver());
						action.moveToElement(address_collections.get(1)).click().build().perform();
						input_address.sendKeys(actualTxt);
						waitABit(1000);
						input_address.sendKeys(Keys.ENTER);
						waitABit(1000);
					}else {
						slf4jLogger.info("Invalid Address");
					}
				}
			}catch (Exception e) {
			}

		} 
		else {

			System.out.println("Address is Empty");
		}
		slf4jLogger.info("Entered the following Customer details for firstName=" + firstName + ", lastName=" + lastName + " ,PhoneNumber=" + contactNum + " address=" + address + "and email=" + email );
	}
	/////////// show Addresss Functionality 03/01   ///////////

	@Step
	public void create_new_account_showAddress(String firstName, String lastName, String contactNum, String Address)
	{
		int iframes_Count =getDriver().findElements(By.tagName("iframe")).size();
		System.out.println("Frames Count for Account creation  "+iframes_Count);
		WebElement frameElement=getDriver().findElement(By.xpath("//iframe[contains(@src,'ServiceAddressCreation')]"));
		//iframe[@id='ext-comp-1050']
		if(frameElement.isDisplayed()){
			String frameName=frameElement.getAttribute("name");
			System.out.println("Account creation Frame name is  "  +frameName);
			getDriver().switchTo().frame(frameName);
			WebDriverWait wait = new WebDriverWait(getDriver(),30);
			wait.until(ExpectedConditions.visibilityOf(customerDetailsPage.address_avail_flag));
			customerDetailsPage.tbx_account_first_name.sendKeys(firstName);
			System.out.println("Entered First Name and ALL Looks Good");
			customerDetailsPage.tbx_account_last_name.sendKeys(lastName);
			customerDetailsPage.tbx_phone_number.sendKeys(contactNum);
			waitABit(1000);
			customerDetailsPage.show_address.click();
			waitABit(1000);
			// click on Show address fields
			if(Address.contains("~"))
			{
				String splitAddress[]= Address.split("~");
				String street= splitAddress[0];
				String city= splitAddress[1];
				String state= splitAddress[2];
				String postalCode= splitAddress[3];
				customerDetailsPage.input_serviceStreet.sendKeys(street);
				customerDetailsPage.input_serviceCity.sendKeys(city);
				customerDetailsPage.input_serviceState.sendKeys(state);
				//customerDetailsPage.input_serviceStreet2.sendKeys(contactNum);
				customerDetailsPage.input_servicezipCode.sendKeys(postalCode);
			}
		}else{
			System.out.println("Frame is Not Available");
		}
	}

	//anuradha: code to select residence option
	@Step
	public void  i_select_own_or_rent(String Residence){
		waitABit(1000);
		customerDetailsPage.ownorrent.selectByVisibleText("Own");	


	}
	//Prepaid Nitish
	@Step
	public void EnterPreapid_detailsoneshopage(String first, String last, String phone, String address) {
		customerDetailsPage.shouldExist(customerDetailsPage,60);
		waitABit(10000);
		customerDetailsPage.firstNam.sendKeys(first);
		customerDetailsPage.lastNam.sendKeys(last);
		customerDetailsPage.phoneNum.sendKeys(phone);
		customerDetailsPage.showAddress.sendKeys(address);
		slf4jLogger.info("Entered the following Customer details for Env= firstName=" + first + ", lastName=" + last + " ,PhoneNumber=" + phone + " and address=" + address);


	}
	
	@Step
	public void SMBEnterPreapid_detailsoneshopage(String first, String last, String phone, String address) {
		customerDetailsPage.shouldExist(customerDetailsPage,60);
		waitABit(10000);
		customerDetailsPage.cbx_business.click();
		customerDetailsPage.tbx_business_name.sendKeys("SMB Business Ltd");
		customerDetailsPage.tbx_account_type.sendKeys("C");
		customerDetailsPage.firstNam.sendKeys(first);
		customerDetailsPage.lastNam.sendKeys(last);
		customerDetailsPage.phoneNum.sendKeys(phone);
		customerDetailsPage.showAddress.sendKeys(address);
		slf4jLogger.info("Entered the following Customer details for Env= firstName=" + first + ", lastName=" + last + " ,PhoneNumber=" + phone + " and address=" + address);


	}

	
	@Step
	public void EnterPreapid_detailsoneshopage(String first, String last, String phone) {
		customerDetailsPage.shouldExist(customerDetailsPage,60);
		waitABit(5000);
		customerDetailsPage.firstNam.sendKeys(first);
		customerDetailsPage.lastNam.sendKeys(last);
		customerDetailsPage.phoneNum.sendKeys(phone);
		customerDetailsPage.lnk_open_account.click();
	}
	/*
	 * Code for SFC Lightning Version - Nitish
	 */
	@Step
	public void SFC_AlertHandling() {

		List<WebElement> alert=getDriver().findElements(By.xpath("//button[contains(text(),'Verified')]"));
		int size=alert.size();
		System.out.println(size);
		if(size>0) {
			List<WebElement> alert1=getDriver().findElements(By.xpath("//*[@data-key='close']"));
			int size1=alert1.size();
			System.out.println("Alert Element size "+size);
			//This Condition Working Fully fine for Chrome Driver Version 79
			for(int i=0;i<size1;i++) {
				try {
					System.out.println("Alert iteration "+i);
					System.out.println(alert1.iterator().next().getAttribute("class"));
					alert1.iterator().next().click();
					break;
				}
				catch(Exception e) {
					System.out.println("Exception Caught and Handled "+e);
				}
			}
			//This Condition Working Paritally fine for Chrome Driver Version 78
			int j=1;
			while(j<=size1) {
				System.out.println("Iteration of alert "+j);
				//if(size>=2) {
				try {
					slf4jLogger.info("Alert Displayed");
					WebElement alert2=getDriver().findElement(By.xpath("(//*[@data-key='close'])["+j+"]"));
					alert2.click();
					slf4jLogger.info("Alert Closed");
					//break;
				}
				catch(Exception e){
					System.out.println("Exception caught for alert"+e);
				}
				System.out.println("Out of Try and Catch Block");
				//	}	
				j++;
			}
		}
	}


	//LC address validation // ac31339

	@Step
	public void click_radio_yes() {
		waitABit(2000);
		customerDetailsPage.input_yes.click();
		slf4jLogger.info("clicked on to Radio Button Yes");

	}

	public void EnterPreapid_businessdetails(String businessName, String accountType, String first, String last,
			String phone, String address) {
		customerDetailsPage.shouldExist(customerDetailsPage,60);
		waitABit(10000);
		customerDetailsPage.customerType.click();
		customerDetailsPage.businessName.sendKeys(businessName);
		customerDetailsPage.accountType.sendKeys(accountType);
		customerDetailsPage.firstNam.sendKeys(first);
		customerDetailsPage.lastNam.sendKeys(last);
		customerDetailsPage.phoneNum.sendKeys(phone);
		customerDetailsPage.showAddress.sendKeys(address);
		slf4jLogger.info("Entered the following Customer details businessName="+businessName+"customerType="+accountType+"firstName=" + first + ", lastName=" + last + " ,PhoneNumber=" + phone + " and address=" + address);
}

	public void fetchOrder() {
		getDriver().findElement(By.xpath("//a[contains(.,'Account or Order already exists')]")).click();
		System.out.println(Serenity.sessionVariableCalled("orderNum").toString());
		getDriver().findElement(By.xpath("//input[@id='orderNumber']")).sendKeys(Serenity.sessionVariableCalled("orderNum").toString());
		waitABit(1000);
		customerDetailsPage.LetsGoButton.click();
		slf4jLogger.info("clicked on to 'Let's Go' button");
		waitABit(10000);
	}

}

