package com.ctl.it.qa.eshop.tools.pages;

import org.openqa.selenium.support.FindBy;

import com.ctl.it.qa.staf.Page;

import net.serenitybdd.core.pages.WebElementFacade;

public class NonpaySuspendPage extends Page{
	//	*****************************************************Web Elements***********************************************

	@FindBy(xpath = "//strong[text()='Suspend products']")
	public WebElementFacade lbl_Suspend_products;

	@Override
	public WebElementFacade getUniqueElementInPage() {
		// TODO Auto-generated method stub
		return null;
	}

	@FindBy(xpath = "//button[text()='Suspend All']")
	public static WebElementFacade btn_Suspend_All;
	
	@FindBy(xpath = "//span[text()='INTERNET']/../ancestor::tbody//tr//td//button[text()='Suspend']")
	public WebElementFacade btn_Hsi_Suspend;
	
	@FindBy(xpath = "//textarea[@title='Remarks']")
	public WebElementFacade txt_NonPaySuspend_AdditionalNotes;
	
	
	
	@FindBy(xpath = "//button[text()='Submit']")
	public static WebElementFacade btn_Submit_NonpaySuspend;

	
	@FindBy(xpath = "//button[text()='Cancel']")
	public WebElementFacade btn_Cancel_NonpaySuspend;
	

	@FindBy(xpath = "//button[text()='Undo']]")
	public WebElementFacade btn_Undo_NonpaySuspend;
	
	@FindBy(xpath = "//span[contains(text(),'Are you sure you want to ')]")
	public WebElementFacade lbl_Order_Disclosures_Nonpay_Suspend;
	
	@FindBy(xpath = "//button[text()='Submit updates']")
	public static WebElementFacade btn_Nonpay_Suspend_Submit_Updates;
	
	
	@FindBy(xpath = "//button[text()='Back to Options']")
	public WebElementFacade btn_Nonpay_Suspend_Back_To_Option;
	
	@FindBy(xpath = "//button[text()='Close X']")
	public WebElementFacade btn_NonpaySuspend_Popup_Closure;
	
	@FindBy(xpath = "//div[contains(text(),'Other Order activities')]")
	public static WebElementFacade ddl_Other_Order_Activities;
}



