package com.ctl.it.qa.eshop.tools.pages;

import org.openqa.selenium.support.FindBy;

import com.ctl.it.qa.staf.Page;

import net.serenitybdd.core.pages.WebElementFacade;

public class MakeChangesPage extends Page {

	@FindBy(xpath = "//button[.='Make Changes']")
	public WebElementFacade btn_make_changes;

	// *****************************************************Overridden
	// Methods*****************************************
	@Override
	public WebElementFacade getUniqueElementInPage() {
		return btn_make_changes;
	}
}
