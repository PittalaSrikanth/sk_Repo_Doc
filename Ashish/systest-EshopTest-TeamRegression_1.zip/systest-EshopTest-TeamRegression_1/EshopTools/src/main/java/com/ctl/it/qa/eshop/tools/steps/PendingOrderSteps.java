package com.ctl.it.qa.eshop.tools.steps;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.interactions.Actions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ctl.it.qa.eshop.tools.pages.PendingOrderPage;
import com.ctl.it.qa.staf.Steps;

import net.thucydides.core.annotations.Step;
import net.thucydides.core.annotations.findby.By;

@SuppressWarnings("serial")
public class PendingOrderSteps extends Steps{

	private final Logger slf4jLogger = LoggerFactory.getLogger(PendingOrderSteps.class);
	PendingOrderPage pendingorderpage;
	
	@Step
	public void i_click_on_scheduling_button() {
		
		pendingorderpage.shouldExist(pendingorderpage, 60);
		pendingorderpage.scheduling.click();
		slf4jLogger.info("Clicked Scheduling Button on Pending Order Page");
	}

	
	@Step
	public void i_click_on_otheractions_button() {
		waitABit(10000);
		try {
			getDriver().findElement(By.xpath("//button[text()='Close X']")).click();
			System.out.println("There is error in this flow");
		}
		catch(Exception e) {}
		JavascriptExecutor js = (JavascriptExecutor)getDriver();
		js.executeScript("window.scrollBy(0,250)","");
//		pendingorderpage.shouldExist(pendingorderpage, 60);
		pendingorderpage.other_actions_box.click();
		slf4jLogger.info("Clicked other actions on Pending Order Page");
	}


	@Step
	public void i_click_on_cancel_button() {
		pendingorderpage.cancel_order.click();
		slf4jLogger.info("Clicked cancel order on Pending Order Page");	
	}

	
	@Step
	public void i_click_on_submit_button() {
		pendingorderpage.submit_order_button.click();
		slf4jLogger.info("Clicked submit button on Pending Order Page");	
	}


	@SuppressWarnings("deprecation")
	@Step
	public void confirm_cancel() {
		/*waitABit(15000);
		pendingorderpage.cancel_reason.selectByIndex(10);
		slf4jLogger.info("Selected the reason for cancel order");	
		waitABit(5000);
		pendingorderpage.continue_cancel_order.click();
		waitABit(5000);*/
		getDriver().findElement(By.xpath("(//div[contains(.,'Additional notes')])[9]/../div[2]/textarea")).sendKeys("TEST Cancellation");
		pendingorderpage.cancel_order_button.click();
		slf4jLogger.info("cancelation of order confirmed");	
		waitABit(20000);
	}


	public void i_click_on_cancel_button(String cancel) {
/*		waitABit(15000);
		slf4jLogger.info("Now to click other actions button");
		JavascriptExecutor js = (JavascriptExecutor)getDriver();
		js.executeScript("arguments[0].scrollIntoView();",pendingorderpage.other_actions_box);
		Actions actions = new Actions(getDriver());
		actions.moveToElement(pendingorderpage.other_actions_box);
		js.executeScript("arguments[0].click();",pendingorderpage.other_actions_box);
		waitABit(5000);
		slf4jLogger.info("Clicked other actions on Pending Order Page");*/
		pendingorderpage.cancel_order.click();
		slf4jLogger.info("Clicked cancel order on Pending Order Page");	
		waitABit(3000);
		pendingorderpage.cancel_reason.selectByVisibleText(cancel);
		slf4jLogger.info("Selected the reason for cancel order");	
		}
	
	public void i_click_on_place_on_hold_button(String hold) {

		pendingorderpage.hold_order.click();
		slf4jLogger.info("Clicked cancel order on Pending Order Page");	
		waitABit(3000);
		pendingorderpage.hold_reason.selectByIndex(6);
		slf4jLogger.info("Selected the reason for hold order");	
		}
	
	@Step
	public void confirm_hold() {
		/*waitABit(15000);
		pendingorderpage.cancel_reason.selectByIndex(10);
		slf4jLogger.info("Selected the reason for cancel order");	
		waitABit(5000);
		pendingorderpage.continue_cancel_order.click();
		waitABit(5000);*/
		getDriver().findElement(By.xpath(".//label[contains(.,'Additional notes (optional)')]/../textarea")).sendKeys("TEST Cancellation");
		pendingorderpage.hold_order_button.click();
		slf4jLogger.info("Hold of order confirmed");	
		waitABit(20000);
	}
	
	
	@Step
	public void order_remarks(String orderRemarks) {
		pendingorderpage.order_remarks_radio_button.click();
		slf4jLogger.info("Clicked on order remarks radio button on Pending Order Page");
		waitFor(2000);
		pendingorderpage.order_tech_remarks_text.sendKeys(orderRemarks);
		slf4jLogger.info("Entrted order remarks  on Pending Order Page");	
		
	}
	
	
}