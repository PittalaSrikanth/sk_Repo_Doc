package com.ctl.it.qa.eshop.tools.steps;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.junit.Assert;
import org.openqa.selenium.JavascriptExecutor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ctl.it.qa.eshop.tools.common.utils.DatabaseUtils;
import com.ctl.it.qa.eshop.tools.pages.CustomerDetailsPage;
import com.ctl.it.qa.eshop.tools.pages.MakeChangesPage;
import com.ctl.it.qa.eshop.tools.pages.OrderSummaryPage;
import com.ctl.it.qa.staf.Steps;

import net.thucydides.core.annotations.Step;
import net.serenitybdd.core.Serenity;
import net.serenitybdd.core.annotations.findby.By;

public class OrderSummarySteps extends Steps {

	private final Logger slf4jLogger = LoggerFactory.getLogger(OrderSummarySteps.class);
	
	
	OrderSummaryPage orderSummaryPage;
	CustomerDetailsPage customerDetailsPage;
	MakeChangesPage makechangespage;
	LoginSteps loginSteps;
	public static String accountnum;
	public static String ordernum;
	public static String finalEmailUsed;
	public static String finalStatus;
	static String Product;
	
	
	
	@Step
	public void clickYes() throws InterruptedException {
		
				orderSummaryPage.shouldExist(orderSummaryPage,240);
				orderSummaryPage.btn_Acknowledge.waitUntilVisible();
				JavascriptExecutor js = (JavascriptExecutor)getDriver();
				js.executeScript("arguments[0].click();", orderSummaryPage.btn_Acknowledge);
				slf4jLogger.info("clicked on Acknowledge");
			
		}
	@Step
	public void clickSubmitOrder() throws InterruptedException {

//		orderSummaryPage.shouldExist(orderSummaryPage, 60);
//		orderSummaryPage.shouldExist(orderSummaryPage, 20);
//		waitABit(60000);
		waitABit(5000);
		JavascriptExecutor js = (JavascriptExecutor) getDriver();
		js.executeScript("arguments[0].click();", orderSummaryPage.submitOrder);
		slf4jLogger.info("clicked on to submit order");
		/*
		 * try { orderSummaryPage.shouldExist(orderSummaryPage, 60);
		 * slf4jLogger.info("last yes button click1");
		 * orderSummaryPage.submitOrder.click();
		 * slf4jLogger.info("clicked on to submit order"); }catch (Exception e)
		 * { orderSummaryPage.shouldExist(orderSummaryPage, 60);
		 * Thread.sleep(2000); orderSummaryPage.submitOrder.click(); }
		 */
	}

	@Step
	public void orderSummaryPageVerification() {
		orderSummaryPage.shouldExist(orderSummaryPage, 60);
		orderSummaryPage.shouldBeVisible(orderSummaryPage.orderSubmittedverification);
		String orderSubmitted = "Order Submitted Successfully";
		Assert.assertTrue(orderSubmitted.contains(orderSummaryPage.orderSubmittedverification.getText().trim()));
		slf4jLogger.info("Verified the order submitted successfully or not");
	}
	@Step
	public void enterTechnicianRemarks(String techRemarks) {
		orderSummaryPage.remarks.sendKeys(techRemarks);
		slf4jLogger.info("Entered techincal remarks");
	}
	@Step
	public void checkRemarks() {
		String remark = "Technical remarks added";
		String remarksCheck = orderSummaryPage.notes.getText();
		slf4jLogger.info("remarks " + remarksCheck);

		if (remark.equals(remarksCheck)) {

			Assert.assertTrue(remark.equals(remarksCheck));
		}
		slf4jLogger.info("verified techinican remarks is dipslayed correctly or not");
	}
	
	@Step
	public void getAccountNumber() {
		orderSummaryPage.shouldBeVisible(orderSummaryPage.orderNumberText);
		// Nitish
		waitABit(3000);
		String fullOrdernum = orderSummaryPage.orderNumberText.getText();
		int lastindexor = fullOrdernum.toCharArray().length;
		ordernum = fullOrdernum.substring(13, lastindexor);
		String fullAccountnum = orderSummaryPage.accountNumberText.getText();
		int lastindexac = fullAccountnum.toCharArray().length;
		accountnum = fullAccountnum.substring(15, lastindexac);
		slf4jLogger.info("order number = " + fullOrdernum);
		slf4jLogger.info("account number = " + fullAccountnum);
		slf4jLogger.info("Cleaned order number = " + ordernum);
		slf4jLogger.info("Cleaned account number = " + accountnum);
		Product = orderSummaryPage.Product_label.getText();
		
	}

	@Step
	public void validateDueDate(String address) {
		boolean flag = orderSummaryPage.serviceAddress.getText().contains(address.split(",")[0].trim());
		Assert.assertTrue(flag);
		slf4jLogger.info("service address validation =" + orderSummaryPage.serviceAddress.getText());
		flag = orderSummaryPage.activationDate.getText().contains(SchedulingSteps.actualDueDate.split(",")[0].trim());
		Assert.assertTrue(flag);
		slf4jLogger.info("due date validation =" + orderSummaryPage.activationDate.getText());
	}

	// Nitish
	@Step
	public void i_clicked_on_new_order() {

		orderSummaryPage.neworder.waitUntilClickable();
		waitABit(30000);
		orderSummaryPage.neworder.click();
		slf4jLogger.info("Clicked on Start New Order button");
		waitABit(7000);

	}
	@Step
	public void i_enter_existing_account_number(String accountnum) {

		orderSummaryPage.accnumrbn.waitUntilClickable();
		waitABit(3000);
		orderSummaryPage.accnumrbn.click();
		orderSummaryPage.existsaaccnumr.sendKeys(accountnum);
		slf4jLogger.info("Entered existing account number:-  " + accountnum);

	}

	@Step
	public void enter_the_special_remark_in_Additional_Order_Remarks_field(String datapassed) {

		orderSummaryPage.Additional_Order_Remarks.waitUntilClickable();
		orderSummaryPage.Additional_Order_Remarks.sendKeys(datapassed);
		waitABit(3000);
		slf4jLogger.info("Entered special remark in Additional Order Remarks field:-  " + datapassed);
	}

	/**
	 * Step to validate the ensemble details for paperless biling order
	 * 
	 * @param bpNoOfCopies
	 * @param bpSeqNo
	 * @param databaseName
	 * @throws SQLException
	 */
	@Step
	public void validates_Ensemble_Details_For_Paperless_Billing(String bpNoOfCopies, String bpSeqNo,
			String databaseName) throws SQLException {
		boolean b = validate_Ensemble_Details_For_Paperless_Billing(bpNoOfCopies, bpSeqNo, databaseName);
		Assert.assertTrue("Ensemble details incorrect for paperless Billing!!!", b);
	}

	/**
	 * Method to validate the ensemble details for paperless biling order
	 * 
	 * @param bpNoOfCopies
	 * @param bpSeqNo
	 * @param databaseName
	 * @throws SQLException
	 */
	@Step
	public boolean validate_Ensemble_Details_For_Paperless_Billing(String bpNoOfCopies, String bpSeqNo,
			String databaseName) throws SQLException {
		DatabaseUtils dbUtils = new DatabaseUtils();
		int actualbpNoOfCopies = dbUtils.fetch_Paperless_Billing_Details(databaseName, bpNoOfCopies, bpSeqNo);
		String zero = bpNoOfCopies.substring(0, 1);
		String nullValue = bpNoOfCopies.substring(1, bpNoOfCopies.length());
		boolean b = actualbpNoOfCopies == Integer.parseInt(zero) || actualbpNoOfCopies == Integer.parseInt(nullValue);
		return b;
	}

	/**
	 * Step to validate the ensemble email details for paperless billing order
	 * for a particular account number
	 * 
	 * @param emailAddress
	 * @param databaseName
	 * @throws SQLException
	 */
	@Step
	public void validates_Ensemble_Email_Details_For_Paperless_Billing(String emailAddress, String databaseName)
			throws SQLException {
		boolean b = validate_Ensemble_Email_Details_For_Paperless_Billing(emailAddress, databaseName);
		Assert.assertTrue("Ensemble EMAIL details incorrect for paperless Billing!!!", b);
	}

	/**
	 * Method to validate the ensemble email details for paperless billing order
	 * for a particular account number
	 * 
	 * @param emailAddress
	 * @param databaseName
	 * @throws SQLException
	 */
	@Step
	public boolean validate_Ensemble_Email_Details_For_Paperless_Billing(String emailAddress, String databaseName)
			throws SQLException {
		DatabaseUtils dbUtils = new DatabaseUtils();
		String actualEmailAddressFromEnsemble = dbUtils.fetch_Paperless_Billing_Email_Details(databaseName);
		boolean b = actualEmailAddressFromEnsemble.equalsIgnoreCase(emailAddress);
		return b;
	}

	// Anuradha
	@Step
	public void i_clicked_on_back_button() {
		waitABit(1000);

		if (orderSummaryPage.back_btn.isCurrentlyVisible()) {

			orderSummaryPage.back_btn.click();

			waitABit(3000);
		} else {

			slf4jLogger.info("Back button is not visible");
		}

	}
	@Step
	public void i_clicked_on_update_Account_button() {

		orderSummaryPage.updateaccnt.click();
		slf4jLogger.info("Clicked on update account button in Account info page");

	}
	@Step
	public void i_select_mail_my_bill() {
		orderSummaryPage.mailmybill.click();
		slf4jLogger.info("Clicked on update account button in Account info page");
	}
	@Step
	public void i_click_on_change_billing_address() {
		orderSummaryPage.updateBllngaddrs.click();

	}
	@Step
	public void i_click_on_update_billing_address(String streetaddress, String city, String zipcode) {
		// orderSummaryPage.billingadrs.sendKeys();
		// orderSummaryPage.billingadrs.selectByValue("Street Address");
		orderSummaryPage.streetadrsbox.clear();
		waitABit(3000);
		orderSummaryPage.streetadrsbox.sendKeys(streetaddress);
		orderSummaryPage.txtbx_city.clear();
		orderSummaryPage.txtbx_city.sendKeys(city);
		orderSummaryPage.selectstate.selectByVisibleText("Arizona");
		orderSummaryPage.txtbx_zipcd.clear();
		orderSummaryPage.txtbx_zipcd.sendKeys(zipcode);
		orderSummaryPage.validatebtn.click();
		orderSummaryPage.addrs_billing.click();
	}
	@Step
	public void verified_reentrant_of_FN_LN_SMS(String firstname, String lastname, String SMS) {
		orderSummaryPage.txtbx_FN.clear();
		orderSummaryPage.txtbx_FN.sendKeys(firstname);
		orderSummaryPage.txtbx_LN.clear();
		orderSummaryPage.txtbx_LN.sendKeys(lastname);
		orderSummaryPage.txtbx_SMS.clear();
		orderSummaryPage.txtbx_SMS.sendKeys(SMS);

	}
	@Step
	public void verified_marketing_preferences() {

		orderSummaryPage.nodirectmail.click();
		orderSummaryPage.noemail.click();
		orderSummaryPage.notelemrktng.click();
	}

	// Anuradha

	/*
	 * Shilpa MMP7824 - F33405 Verify the display of both Primary contact number
	 * and order level CBR number in Account information page
	 */
	@Step
	public void validatePhoneNumber(String contactNumber) {
		orderSummaryPage.shouldExist(orderSummaryPage, 60);
		orderSummaryPage.shouldBeVisible(orderSummaryPage.orderSubmittedverification);
		slf4jLogger.info("Order Level CBR =" + orderSummaryPage.orderLevelCRB.getText().replaceAll("[\\s\\-()]", ""));
		boolean flag = orderSummaryPage.orderLevelCRB.getText().replaceAll("[\\s\\-()]", "").contains(contactNumber);
		// Assert.assertTrue(flag);
		if (flag)
			slf4jLogger.info("Phone Number Matched with Contact Number edited in scheduling page");
		else
			slf4jLogger.info("Phone Number is not same as edited number in scheduling page");
	}

	/*
	 * Ac43057- Validation for Auth user
	 * 
	 */
	@Step
	public boolean validationForAuthUSer(String authname) {
		orderSummaryPage.shouldExist(orderSummaryPage, 60);
		// String authName = orderSummaryPage.authName.getText();

		String S1 = "//label[contains(text(),'Authorized Parties')]//parent::div/child::p[contains(text(),'";
		String S2 = "')]";
		boolean b = false;
		if (getDriver().findElements(By.xpath(S1 + authname + S2)).size() == 0) {
			b = true;
		}
		slf4jLogger.info("Authorized User name added ---------   " + b);
		return b;
	}
	
	/*
	 * Shilpa - F37432
	 */
	@Step
	public void validateAuthorizedPartyInOrderSummary(String firstName1, String lastName1, String firstName2, String lastName2 ){
		boolean flag=false;
		orderSummaryPage.shouldExist(orderSummaryPage,60);
		//orderSummaryPage.shouldBeVisible(orderSummaryPage.orderSubmittedverification);
		slf4jLogger.info("Authorized Party Details  ="+ orderSummaryPage.authorizedParty.getText().replaceAll("[\\s\\-()]",""));
		String OrderSummaryPageValue =orderSummaryPage.authorizedParty.getText().replaceAll("[\\s\\-()]","");
		if(OrderSummaryPageValue.contains(firstName1)&&OrderSummaryPageValue.contains(firstName2)&&OrderSummaryPageValue.contains(lastName1)&&OrderSummaryPageValue.contains(lastName2))
			flag=true;
		//Assert.assertTrue(flag);		
		if(flag)
			slf4jLogger.info("Authorised Party Data Match");
		else
			slf4jLogger.info("Authorized Party Data Not Matched");
	}
	
	@Step
	public void save_the_Order_and_BAN(String scenarioName) throws EncryptedDocumentException, InvalidFormatException, IOException {
		

		//for(int i=0; i<=2; i++) {
		File orderfile= new File("..\\EshopTools\\src\\test\\resources\\OrderDetails.xlsx");
		Workbook workbook = WorkbookFactory.create(orderfile);
		//Workbook workbook = WorkbookFactory.
		Sheet sheet = workbook.getSheetAt(0);
		slf4jLogger.info("Sheet Name :-  "+sheet);
		slf4jLogger.info("First Row :-  "+sheet.getFirstRowNum());
		slf4jLogger.info("Last Row :-  "+sheet.getLastRowNum());
		int lastrow=sheet.getLastRowNum();
		int newrow=lastrow+1;
		slf4jLogger.info("New Row to write data :-  "+newrow);
		Row row = sheet.createRow(newrow);

	    row.createCell(0).setCellValue(newrow);
	    Date dNow = new Date( );
	      System.out.println("Current System Date: " + dNow);
	      SimpleDateFormat ft = new SimpleDateFormat ("yyyy-MM-dd");
	     // System.out.println("Formated Current Date: " + ft.format(dNow));
	     row.createCell(1).setCellValue(ft.format(dNow));
	     row.createCell(2).setCellValue(scenarioName);
	    row.createCell(3).setCellValue(ordernum);
	    row.createCell(4).setCellValue(accountnum);
	    row.createCell(5).setCellValue(Product);
	    row.createCell(6).setCellValue(finalEmailUsed);
	    row.createCell(7).setCellValue(finalStatus);
	    /*row.createCell(1).setCellValue("1000047242");
	    row.createCell(2).setCellValue("686131599");
	    row.createCell(3).setCellValue("Orders Need Completion so Added Here");*/
		
		
	    /*row.createCell(0).setCellValue(newrow);
	    row.createCell(1).setCellValue("ordernum");
	    row.createCell(2).setCellValue("accountnum");
	    String s=scenario.getName();
	    System.out.println(s);
	    //System.out.println(scenario);
	    row.createCell(3).setCellValue("HSI");
	   */
	   /* for(int i = 0; i < columns.length; i++) {
	        sheet.autoSizeColumn(i);
	    }
	*/
	    FileOutputStream fileOut = new FileOutputStream("..\\EShopTests\\target\\OrderDataDetails.xlsx");
	    workbook.write(fileOut);
	    fileOut.close();
		/*Cell cell;
		cell = ((Sheet) orderfile).getRow(newrow).getCell(0);
		cell.setCellType(Cell.CELL_TYPE_STRING);
		cell.setCellValue("Result");
		*/
		
		//slf4jLogger.info("Sheet Name :-  "+sheet.);
		workbook.close();
		//}
		//}
		
	}
	
	
	@Step
	public void save_the_Order_and_BAN(String scenarioName, String status) throws EncryptedDocumentException, InvalidFormatException, IOException {
		

		//for(int i=0; i<=2; i++) {
		File orderfile= new File("..\\EshopTools\\src\\test\\resources\\OrderDetails.xlsx");
		Workbook workbook = WorkbookFactory.create(orderfile);
		//Workbook workbook = WorkbookFactory.
		Sheet sheet = workbook.getSheetAt(0);
		slf4jLogger.info("Sheet Name :-  "+sheet);
		slf4jLogger.info("First Row :-  "+sheet.getFirstRowNum());
		slf4jLogger.info("Last Row :-  "+sheet.getLastRowNum());
		int lastrow=sheet.getLastRowNum();
		int newrow=lastrow+1;
		slf4jLogger.info("New Row to write data :-  "+newrow);
		Row row = sheet.createRow(newrow);

	    row.createCell(0).setCellValue(newrow);
	    Date dNow = new Date( );
	      System.out.println("Current System Date: " + dNow);
	      SimpleDateFormat ft = new SimpleDateFormat ("yyyy-MM-dd");
	     // System.out.println("Formated Current Date: " + ft.format(dNow));
	     row.createCell(1).setCellValue(ft.format(dNow));
	     row.createCell(2).setCellValue(scenarioName);
	    row.createCell(3).setCellValue(ordernum);
	    row.createCell(4).setCellValue(accountnum);
	    row.createCell(5).setCellValue(Product);
	    row.createCell(6).setCellValue(finalEmailUsed);
	    row.createCell(7).setCellValue(status);
	    /*row.createCell(1).setCellValue("1000047242");
	    row.createCell(2).setCellValue("686131599");
	    row.createCell(3).setCellValue("Orders Need Completion so Added Here");*/
		
		
	    /*row.createCell(0).setCellValue(newrow);
	    row.createCell(1).setCellValue("ordernum");
	    row.createCell(2).setCellValue("accountnum");
	    String s=scenario.getName();
	    System.out.println(s);
	    //System.out.println(scenario);
	    row.createCell(3).setCellValue("HSI");
	   */
	   /* for(int i = 0; i < columns.length; i++) {
	        sheet.autoSizeColumn(i);
	    }
	*/
	    FileOutputStream fileOut = new FileOutputStream("..\\EShopTests\\target\\OrderDataDetails.xlsx");
	    workbook.write(fileOut);
	    fileOut.close();
		/*Cell cell;
		cell = ((Sheet) orderfile).getRow(newrow).getCell(0);
		cell.setCellType(Cell.CELL_TYPE_STRING);
		cell.setCellValue("Result");
		*/
		
		//slf4jLogger.info("Sheet Name :-  "+sheet.);
		workbook.close();
		//}
		//}
		
	}
	

	/*
	 * Complete Order Web Tool Code - Nitish
	 */
/*	@Step
	public void Web_Tool_to_Complete_Provisioning_of_the_Order_in_Env(String envName) {
		waitABit(300000);
		slf4jLogger.info("Open Web Tool up By New Tab ....");		
		JavascriptExecutor js = (JavascriptExecutor) getDriver();
		js.executeScript("window.open()");
		Set<String> allWindows=getDriver().getWindowHandles();
		Iterator<String> windowIterator=allWindows.iterator();
		String parentWindow=windowIterator.next();
		String childWindow=windowIterator.next();
		getDriver().switchTo().window(childWindow);
		getDriver().get("http://x1074509:8080/WebTestTools/CompleteOrder.html");
		slf4jLogger.info("Web Tool Complete Order Launched");
		orderSummaryPage.Environment.selectByValue(envName);
		slf4jLogger.info("Selected Enviroment in Web Tool as "+envName);
		orderSummaryPage.Order_number.sendKeys(ordernum);
		slf4jLogger.info("Entered Order Number in Web Tool as "+ordernum);
		try {
			System.out.println("Waiting for Provisioning and Billing of the order...");
			slf4jLogger.info("Clicked Submit Button");
			orderSummaryPage.Submit.click();
		}
		catch(Exception e) {
			System.out.println("Ignoring Timeout Exception...");
		}
		System.out.println("Now resuming with order validation steps...");
//		ArrayList<String> tabs2 = new ArrayList<String> (getDriver().getWindowHandles());
//		getDriver().switchTo().window(tabs2.get(0));
//		waitABit(5000);
//		waitABit(600000);
//		slf4jLogger.info("Clicked Submit Button");
//		slf4jLogger.info("Waiting 3 minutes for Order to be completed");
//		getDriver().switchTo().window(parentWindow);
//		slf4jLogger.info(".... Web Tool Execution Done");		
	}
*/	
	public void validateOrderCompletion() {
		waitABit(300000);
		JavascriptExecutor js = (JavascriptExecutor) getDriver();
		js.executeScript("window.open()");
		Set<String> allWindows=getDriver().getWindowHandles();
		Iterator<String> windowIterator=allWindows.iterator();
		String parentWindow=windowIterator.next();
		String childWindow1=windowIterator.next();
		String childWindow2=windowIterator.next();
		getDriver().switchTo().window(childWindow2);
//		loginSteps.Eshop_url_OpenPage();
//		getDriver().get("https://eshop-test2.test.intranet/eshop/customerCare/dist/index.html");
		String url=envData.getFieldValue("eshop-url");
		getDriver().get(url);
	}
	public void validateMakeChanges() {
//		customerDetailsPage.tbx_enter_order.sendKeys("1003330966");
		customerDetailsPage.tbx_enter_order.sendKeys(ordernum);
		waitABit(2000);
		customerDetailsPage.LetsGoButton.click();
		waitABit(25000);
//		makechangespage.shouldExist(makechangespage, 240);
//		waitABit(5000);
		boolean ready_flag=customerDetailsPage.btn_make_changes.isCurrentlyEnabled();
		if(ready_flag) {
		System.out.println("Order Successfully Completed"+" Ready Flag: "+ready_flag);
		finalStatus="ESHOP ORDER SUCCESSFUL";
		}
		else {
			System.out.println("Order NOT Successfully Completed"+" Ready Flag: "+ready_flag);
			finalStatus="ESHOP ORDER PROVISIONING/BILLING FAILED";
		}
	}

	
	
	@Step
	public void Web_Tool_to_Complete_Provisioning_of_the_Order_in_Env(String envName) {
		String acnum=OrderSummarySteps.accountnum;
		Serenity.setSessionVariable("acnum_kal").to(acnum);
		
		System.out.println("Current Env >>>>>>>" + getDriver().getCurrentUrl());
		slf4jLogger.info("Open Web Tool up By New Tab ....");
		JavascriptExecutor js = (JavascriptExecutor) getDriver();
		js.executeScript("window.open()");
		Set<String> allWindows = getDriver().getWindowHandles();
		Iterator<String> windowIterator = allWindows.iterator();
		String parentWindow = windowIterator.next();
		String childWindow = windowIterator.next();
		getDriver().switchTo().window(childWindow);
		getDriver().get("http://x1074509:8080/WebTestTools/CompleteOrder.html");
		waitABit(300000); // waiting orders to reach SR
		slf4jLogger.info("Web Tool Complete Order Launched");

		try {
			//System.out.println(Environment.getCurrentEnvironment());
			orderSummaryPage.Environment.selectByValue(envName);
			slf4jLogger.info("Selected Enviroment in Web Tool as " + envName);
			orderSummaryPage.Order_number.sendKeys(ordernum);
			slf4jLogger.info("Entered Order Number in Web Tool as " + ordernum);
			waitABit(15000);
			System.out.println("Entered Order number >>>>>>>>>");
			orderSummaryPage.Submit.click();

		} catch (Exception ex) {
			slf4jLogger.info("Tried to click Submit Button");
		}
		slf4jLogger.info("Clicked Submit Button");
		slf4jLogger.info("Waiting 5 minutes for Order to be completed");
		waitABit(300000);
		//waitABit(300000);
		//waitABit(180000);
		getDriver().switchTo().window(parentWindow);
		slf4jLogger.info(".... Web Tool Execution Done");
		waitABit(8000);
		ArrayList<String> tabs2 = new ArrayList<String> (getDriver().getWindowHandles());
		waitABit(4000);
		getDriver().switchTo().window(tabs2.get(1)).close();
		waitABit(2000);
		getDriver().switchTo().window(tabs2.get(0));
		waitABit(5000);
	}
}
