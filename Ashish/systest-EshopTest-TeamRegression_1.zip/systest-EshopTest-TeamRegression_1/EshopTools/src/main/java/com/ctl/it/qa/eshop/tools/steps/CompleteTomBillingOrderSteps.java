package com.ctl.it.qa.eshop.tools.steps;

import static org.junit.Assert.assertEquals;

import java.io.File;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import org.openqa.selenium.JavascriptExecutor;
//import com.ctl.it.qa.bm.utils.BMUtils;
import com.ctl.it.qa.staf.Page;
import com.ctl.it.qa.staf.Steps;
import net.serenitybdd.core.annotations.findby.By;
import net.thucydides.core.annotations.Step;

public class CompleteTomBillingOrderSteps extends Steps {
	/**
	 * 
	 */
	private static final long serialVersionUID = -2771232118946892926L;
	String BillingStatus=null;
	String TOMStatus=null;
	//Jar file websop order completion by Tara Kibler
	@Step
	public void Complete_TOM_and_Billing_Tasks() 
		{	
//		        String orderNumber = OrderSummarySteps.ordernum;
//				System.out.println("Order No. is  "+orderNumber);
//				waitABit(10000);
//		        String env = Page.currentEnvironment.getKey();
//		          if (env.equals("TEST4")) {
//		        	  env="E2E";
//		          } 
//		          else if(env.equals("TEST1")) {
//		        	  env="Test1";
//		          }
//		          else if(env.equals("TEST2")) {
//		        	  env="Test2";
//		          }
//		          System.out.println("Current Environment is   "+env);
//		          String numberOfDays = "2";
//		          String sFFWF = "false";
//		          String sTOM = "true";
//		          String sBilling = "true";
//		          boolean cpFFWF = false;
//		          if (sFFWF.equals("true"))
//		                cpFFWF = true;
//		          boolean cpTOM = false;
//		          if (sTOM.equals("true"))
//		                cpTOM = true;
//		          boolean ckBilling = false;
//		          if (sBilling.equals("true"))
//		        	  ckBilling = true;          
//		          if (OrderSummarySteps.Product.equals("CENTURYLINK INTERNET"))
//		        	  ckBilling = false;
//		          System.out.println("Going to run test with " + orderNumber + env + numberOfDays + sFFWF + sTOM + ckBilling);
//
//		          String ban = BMUtils.getBANforOrderNumber(env, orderNumber);
//		          if (ban.length() < 1) {
//		                System.out.println("Unable to retrieve BAN");
//		                return;
//		          }
//
//		          List<String[]> serviceRegistryData = BMUtils.getServiceRegistryData(env, orderNumber);
//
//		          String response = "";
////Not Required As not Completing FFWF with this Jar
//		          try {
//		                if (cpFFWF) {
//		                      System.out.println("Searching for FFWF Ids... Please wait...");
//		                      response = BMUtils.completeFFWFEntries(env, ban, orderNumber, serviceRegistryData);
//		                      System.out.println(response);
//
//		                           }
//		                // If the box to complete the TOM order is checked...
//		                if (cpTOM) {
//		                      String filePathString = "\\\\co5325gwebsop3\\Test_Tools\\TOM\\tom.cfg";
//		                      File f = new File(filePathString);
//		                      if (!f.exists()) {
//		                            System.out.println(
//		                                        "Cannot get config info.  Is co5325gwebsop3 asleep?  Wake with http://vwodsema001/WRA/");
//		                           return;
//		                                      }
//		                      System.out.println("Searching for TOM Orders... Please wait...");
//		                      List<String> customerServiceOrderNumbers = new ArrayList<String>();
//		                      int USOcount = 0;
//		                      for (String[] record : serviceRegistryData) {
//		                            String customerServiceOrderNumber = record[4];
//		                      if (!customerServiceOrderNumbers.contains(customerServiceOrderNumber)) {
//		                                                customerServiceOrderNumbers.add(customerServiceOrderNumber);
//		                            List<String> USOOrderNumbers = BMUtils.getUSOOrderNumberByCSNO(env, customerServiceOrderNumber);
//		                            for (String USOOrderNumber : USOOrderNumbers) {
//		                                  USOcount++;
//		                                  response = BMUtils.completeTOMOrder(env, ban, USOOrderNumber, orderNumber, "2");
//		                                  TOMStatus=response;
//		                                  System.out.println(response);
//		                                  System.out.println("The TOM Response Value :"+TOMStatus);
//		                                                                         }
//		                                                                                           }
//		                                                                   }
//		                      if (USOcount < 1)
//		                        System.out.println("Could not find any TOM orders to complete");        
//		                         }
//		                if (ckBilling) {
//		                	System.out.println("The Raw Billing Response Value :"+response);
//		    				System.out.println("Retrieving billing information... Please wait...");
//		    				Thread.sleep(30000L);
//		    				response = BMUtils.checkBillingEntries(env, orderNumber);
//		    				System.out.println("The Raw Billing Response Recived :"+response);
//		    				if (response.equals(""))
//		    					response = "Billing successful";
//		    				System.out.println("The Billing Response Recived :"+response);
//		    				BillingStatus=response;
//		    				System.out.println("The Billing Status is :"+BillingStatus);
//		    			}
//		          }
//		    		 catch (Exception e) {
//		    			String errorMessage = e.toString();
//		    			System.out.println(errorMessage);		
//		          }
//		          // assertEquals("TOM completion has been Failed", "TOM completion successfully sent.", TOMStatus);
//		          //if (ckBilling) {
//		          //assertEquals("Billing has been Failed", "Billing successful", BillingStatus);
//		         // }              
		}	

	@Step
	public void wake_up_remote_computer() {
		Set<String> allWindows=getDriver().getWindowHandles();
		if(allWindows.size() >= 2) {
			Iterator<String> windowIterator=allWindows.iterator();
			String parentWindow=windowIterator.next();
			String childWindow=windowIterator.next();
			System.out.println(allWindows);
			getDriver().switchTo().window(parentWindow);
		waitABit(3000);
		System.out.println("Trying to Wake up Remote Computer ...");
		//getDriver().navigate().to("http://vwodsema001/WRA/");
		getDriver().get("http://vwodsema001/WRA/");
		waitABit(1000);
		getDriver().findElement(By.xpath("//input[@type='text']")).sendKeys("co5325gwebsop3");
		waitABit(1000);
		getDriver().findElement(By.xpath("//input[@type='submit']")).click();
		waitABit(1000);
		getDriver().findElement(By.xpath("//input[@value='Wake']")).click();
		waitABit(5000);
		getDriver().navigate().back();
		getDriver().navigate().back();
		getDriver().navigate().back();
		waitABit(1000);
		System.out.println("... Remote Computer Wake up Successful");
			getDriver().switchTo().window(childWindow);
		}
		else {
			System.out.println("Remote Computer Wake up By New Tab ....");
			JavascriptExecutor js = (JavascriptExecutor) getDriver();
			js.executeScript("window.open()");
			Set<String> allWindows1=getDriver().getWindowHandles();
			Iterator<String> windowIterator=allWindows1.iterator();
			String parentWindow=windowIterator.next();
			String childWindow=windowIterator.next();
			System.out.println(allWindows);
			getDriver().switchTo().window(childWindow);
			getDriver().get("http://vwodsema001/WRA/");
			waitABit(1000);
			getDriver().findElement(By.xpath("//input[@type='text']")).sendKeys("co5325gwebsop3");
			waitABit(1000);
			getDriver().findElement(By.xpath("//input[@type='submit']")).click();
			waitABit(1000);
			getDriver().findElement(By.xpath("//input[@value='Wake']")).click();
			waitABit(5000);
			getDriver().switchTo().window(parentWindow);
			System.out.println(".... Remote Computer Wake up Successful");
		}
	}
	@Step
	public void checkBillingStatus() {
		assertEquals("Billing has been Failed", "Billing successful", BillingStatus);		
	}

}



