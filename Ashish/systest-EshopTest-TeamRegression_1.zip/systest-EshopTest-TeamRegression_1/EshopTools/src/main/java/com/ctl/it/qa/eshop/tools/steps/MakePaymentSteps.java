package com.ctl.it.qa.eshop.tools.steps;

import org.junit.Assert;
import org.openqa.selenium.JavascriptExecutor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.ctl.it.qa.eshop.tools.pages.MakePaymentPage;
import com.ctl.it.qa.staf.Steps;

import net.thucydides.core.annotations.Step;

public class MakePaymentSteps extends Steps {

	private final Logger slf4jLogger = LoggerFactory.getLogger(MakePaymentSteps.class);
	MakePaymentPage makePaymentPage;

	@Step
	public void verifyMakePaymentPage() {
		makePaymentPage.shouldExist(makePaymentPage,120);
		boolean flag = makePaymentPage.makePaymentPageText.isDisplayed();
		slf4jLogger.info("flag value =" + flag);
		Assert.assertTrue(flag);
		slf4jLogger.info("Verified payment page");
	}

	@Step
	public void fillCardDetails(String card, String zipcode) {
		getDriver().switchTo().frame(0);
		slf4jLogger.info("frame switched");
		makePaymentPage.ddl_methodOfPayment.selectByIndex(2);
		makePaymentPage.cardNumBox.sendKeys(card);
		makePaymentPage.expiryMonthdrpDwn.selectByIndex(4);
		makePaymentPage.expiryYearDrpdwn.selectByIndex(4);
		makePaymentPage.zipCodeBox.clear();
		makePaymentPage.zipCodeBox.sendKeys(zipcode);
		makePaymentPage.tncCheckBox.click();
		JavascriptExecutor js = (JavascriptExecutor) getDriver();
		js.executeScript("arguments[0].scrollIntoView();", makePaymentPage.nextButton);		
		makePaymentPage.nextButton.click();
		slf4jLogger.info("Filled all the card details");
	}

	public void fillDepositPaymentDetails(String card, String zipcode) {
		slf4jLogger.info("Checking elements in the frames");
		//		waitABit(15000);
		for(int i=0;i<=8;i++) {
			try {
				waitABit(60000);
				getDriver().switchTo().frame(i);
				makePaymentPage.cardNumBox.sendKeys(card);
				slf4jLogger.info("frame switched: "+i);
				break;
			}
			catch(Exception e) {
				continue;
			}
		}

		makePaymentPage.expiryMonthdrpDwn.selectByIndex(4);
		makePaymentPage.expiryYearDrpdwn.selectByIndex(4);
		makePaymentPage.zipCodeBox.clear();
		makePaymentPage.zipCodeBox.sendKeys(zipcode);
		makePaymentPage.tncCheckBox.click();
		JavascriptExecutor js = (JavascriptExecutor) getDriver();
		js.executeScript("arguments[0].scrollIntoView();", makePaymentPage.nextButton);		
		makePaymentPage.nextButton.click();
		slf4jLogger.info("Filled all the card details");
	}

	@Step
	public void submitVerfiyInfo() {
		waitABit(10000);
		makePaymentPage.submitBtn.click();
		slf4jLogger.info("Clicked on to submit button");
		getDriver().switchTo().defaultContent();
		slf4jLogger.info("Out of Frame : Moved default");
	}

}