package com.ctl.it.qa.eshop.tools.pages;

import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import com.ctl.it.qa.staf.Page;
import net.serenitybdd.core.pages.WebElementFacade;

public class CustomerDetailsPage extends Page {

	@FindAll({		
		@FindBy(xpath = "//input[@id='firstName']"),
		@FindBy(xpath = "//span[contains(text(),'Accounts')]")
	})
	public WebElementFacade firstNam;

	@FindBy(xpath = "//input[@id='lastName']")
	public WebElementFacade lastNam;

	@FindBy(xpath = "//input[@id='BUSINESS']")
	public WebElementFacade cbx_business;

	@FindBy(xpath = "//input[@id='businessName']")
	public WebElementFacade tbx_business_name;

	@FindBy(xpath = "//input[@id='accountType']")
	public WebElementFacade tbx_account_type;

	@FindBy(xpath = "//a[.='Account or Order already exists']")
	public WebElementFacade lnk_open_account;

	@FindBy(xpath = ".//img[contains(@id,'interstitial-image')]")
	public WebElementFacade lbl_spinner;



	@FindBy(xpath = "//input[@title='Order Number']")
	public WebElementFacade tbx_enter_order;


	@FindBy(xpath = "//button[.='Make Changes']")
	public WebElementFacade btn_make_changes;


	@FindBy(id = "businessName")
	public WebElementFacade businessName;

	@FindBy(id = "accountType")
	public WebElementFacade accountType;

	@FindBy(id = "BUSINESS")
	public WebElementFacade customerType;

	@FindBy(id = "phoneNumber")
	public WebElementFacade phoneNum;

	@FindBy(xpath = "//input[@id='address']")
	public WebElementFacade showAddress;

	@FindBy(xpath = "//button[@type='submit']")
	public WebElementFacade LetsGoButton;

	@FindBy(xpath = "//div[text()='No Results Found']")
	public WebElementFacade noMatchFoudText;

	@FindBy(xpath = ".//*[@id='addressLine']")
	public WebElementFacade street;

	@FindBy(xpath = ".//*[@id='floor']")
	public WebElementFacade unit;

	@FindBy(xpath = ".//*[@id='state']")
	public WebElementFacade state;

	@FindBy(xpath = ".//*[@id='city']")
	public WebElementFacade city;

	@FindBy(xpath = ".//*[@id='zipCode']")
	public WebElementFacade zipcode;

	@FindBy(xpath = "html/body/app/main/ctl-home/address/section/div/div[1]/div/form/div[2]/div/div/div[3]/div[1]/a")
	public WebElementFacade showalladdress;

	@FindBy(xpath = "html/body/app/main/multiplematchaddress/section/div/div/div/form/div[2]/div/div[3]/div[2]/div/ul/li[1]/label/input")
	public WebElementFacade selectradiobtn;

	@FindBy(xpath = "//button[@class='btn btn-primary activeBtn']")
	public WebElementFacade continuebtn;
	//Nitish

	@FindBy(xpath = "//a[contains(text(),'Account or Order already exists')]")
	public WebElementFacade orderexists;

	@FindBy(xpath = "//a[contains(text(),'Start New Customer Order')]")
	public WebElementFacade newcustomer;	

	@FindBy(xpath = "(//input[@name='number'])[1]")
	public WebElementFacade accnumrbn;

	@FindBy(xpath = "//input[@id='accountNumber']")
	public WebElementFacade existsaaccnumr;

	//Prem SFC Integeration Starts 


	@FindBy(xpath = "//div[text()='Drag Footer Components Here']")
	public WebElementFacade lbl_drag_footer_component_here;

	@FindBy(xpath = "//span[text()='Close all primary tabs']")
	public WebElementFacade lnk_close_all_primary_tabs;

	@FindBy(xpath = "//span[text()='Pop out primary tabs']")
	public WebElementFacade lnk_pop_out_primary_tabs;

	@FindBy(xpath = "(//div[@class='x-tab-tabmenu-right'])[1]")
	public WebElementFacade btn_right_tab_menu;

	@FindBy(xpath = "//span[contains(text(),'Accounts')]")
	public WebElementFacade btn_account;

	//Prem SFC Integeration Ends 

	@FindBy(xpath = "//div[contains(text(),'Address & TN Live Help')]")
	public WebElementFacade address_avail_flag;

	///////////////  Elements for Show address 03/01 ////////////

	@FindBy(xpath = "(//input[contains(@id,'AccSerStreet')])[1]")
	public WebElementFacade input_serviceStreet;

	@FindBy(xpath = "(//input[contains(@id,'AccSerCity')])[1]")
	public WebElementFacade input_serviceCity;

	@FindBy(xpath = "(//input[contains(@id,'AccSerState')])[1]")
	public WebElementFacade input_serviceState;

	@FindBy(xpath = "(//input[contains(@id,'AccSerZipCode')])[1]")
	public WebElementFacade input_servicezipCode;

	@FindBy(xpath = "(//input[contains(@id,'AccSerStreet2')])[1]")
	public WebElementFacade input_serviceStreet2;

	@FindBy(xpath = "//input[@value='Show Address Fields']")
	public WebElementFacade show_address;

	@FindBy(xpath = "//input[@value='Hide Address Fields']")
	public WebElementFacade hide_address;

	@FindBy(xpath = "//span[@title='Close']")
	public WebElementFacade btn_close;	

	//Abhinav

	@FindBy(css = "#orderNumber")
	public WebElementFacade txt_Existing_Information_Order_Number;

	@FindBy(xpath = "//button[contains(text(),'Let')]")
	public WebElementFacade btn_Lets_Go;

	@FindBy(css = "#firstName")
	public WebElementFacade txt_First_Name_ESHOP;

	@FindBy(css = "#lastName")
	public WebElementFacade txt_Last_Name_ESHOP;

	@FindBy(css = "#phoneNumber")
	public WebElementFacade txt_Contact_Number_ESHOP;

	@FindBy(xpath = "(//input[@id='pageId:formId:pblock:mainRecord:AccEml:AccEmail'])[1]")
	public WebElementFacade txt_Email;

	///////////////  Elements for Show address 03/01 ////////////
	/*
	 * Xpaths Updated with SFC Lightining Version - Nitish
	 */
	@FindBy(xpath = "//div[@title='New']")
	public WebElementFacade btn_createnew;

	@FindBy(xpath = "(//span[contains(text(),'Accounts')])[1]")
	public WebElementFacade link_account;

	@FindBy(xpath = "(//label[contains(text(),'First Name')]/following::input)[1]")
	public  WebElementFacade tbx_account_first_name;

	@FindBy(xpath = "(//label[contains(text(),'First Name')]/following::input)[2]")
	public  WebElementFacade tbx_account_last_name;

	@FindBy(xpath = "(//label[contains(text(),'First Name')]/following::input)[3]")
	public  WebElementFacade tbx_phone_number;

	@FindBy(xpath = "(//label[contains(text(),'First Name')]/following::input)[3]")
	public  WebElementFacade tbx_smb_account_name;

	@FindBy(xpath = "(//label[contains(text(),'First Name')]/following::input)[4]")
	public  WebElementFacade tbx_smb_entity_type;

	@FindBy(xpath = "(//label[contains(text(),'First Name')]/following::input)[5]")
	public  WebElementFacade tbx_smb_primary_contact;

	@FindBy(xpath = "(//label[contains(text(),'First Name')]/following::input)[7]")
	public  WebElementFacade tbx_smb_business_phone_num;

	@FindBy(xpath = "(//label[contains(text(),'First Name')]/following::input)[8]")
	public  WebElementFacade tbx_smb_email;









	@FindBy( xpath = "(//label[contains(text(),'First Name')]/following::input)[5]")
	public WebElementFacade tbx_Email;

	@FindBy(xpath = "(//label[contains(text(),'First Name')]/following::input)[6]")
	public  WebElementFacade tbx_address_field;

	@FindBy(xpath = "(//label[contains(text(),'First Name')]/following::input)[9]")
	public  WebElementFacade tbx_address_smb_field;

	@FindBy(xpath = "(//label[contains(text(),'First Name')]/following::input)[7]")
	public WebElementFacade ownorrent;

	@FindBy(xpath = "//*[@data-value='Own']")
	public WebElementFacade select_own_house;		

	@FindBy(xpath = "(//label[contains(text(),'First Name')]/following::input)[7]/following::button[2]")
	public  WebElementFacade btn_validate_address;

	@FindBy(xpath = "(//label[contains(text(),'First Name')]/following::input)[7]/following::button[1]")
	public  WebElementFacade btn_save;

	@FindBy(xpath = "(//button[contains(text(),'Order (eShop)')])[3]")
	public WebElementFacade btn_order_eshop;

	//LC address validation ac31339
	@FindBy(xpath = "//input[@value='Yes']")
	public WebElementFacade input_yes;


	@Override
	public WebElementFacade getUniqueElementInPage() {
		return firstNam;
	}



}
