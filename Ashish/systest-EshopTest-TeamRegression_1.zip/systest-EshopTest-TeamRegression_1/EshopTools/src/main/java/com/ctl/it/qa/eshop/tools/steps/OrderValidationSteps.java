package com.ctl.it.qa.eshop.tools.steps;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Map;
import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.ctl.it.qa.staf.Page;
import com.ctl.it.qa.staf.Steps;
import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.MongoClient;
import com.mongodb.MongoClientURI;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import junit.framework.Assert;
import net.serenitybdd.core.Serenity;
import net.thucydides.core.annotations.Step;
import net.thucydides.core.annotations.findby.By;

@SuppressWarnings("serial")
public class OrderValidationSteps extends Steps  {

	@SuppressWarnings("deprecation")
	
	@Step
	public void getOrderDetails() throws EncryptedDocumentException, InvalidFormatException, IOException {
		FileInputStream fisFirst=new FileInputStream("..\\EshopTools\\src\\test\\resources\\OrderStatus.xlsx");
		@SuppressWarnings("resource")
		XSSFWorkbook wb= new XSSFWorkbook(fisFirst);
		XSSFSheet sheet=wb.getSheet("Sheet1");
		int rowcount=sheet.getLastRowNum();
		System.out.println("Total number of orders: "+rowcount);
		for(int i=1; i<=rowcount;i++) {
			sheet.getRow(i).getCell(0).setCellType(Cell.CELL_TYPE_STRING);
			String orderNumber=sheet.getRow(i).getCell(0).getStringCellValue();
			//			sheet.getRow(i).getCell(1).setCellType(Cell.CELL_TYPE_STRING);
			//			String status=sheet.getRow(i).getCell(1).getStringCellValue();
			sheet.getRow(i).getCell(2).setCellType(Cell.CELL_TYPE_STRING);
			String action=sheet.getRow(i).getCell(2).getStringCellValue();
			sheet.getRow(i).getCell(3).setCellType(Cell.CELL_TYPE_STRING);
			String execute=sheet.getRow(i).getCell(3).getStringCellValue();
			if(execute.equals("Y")) {
				performAction(orderNumber,action,i);
				break;
			}

		}
		fisFirst.close();
		/*		FileOutputStream fos=new FileOutputStream("..\\EshopTools\\src\\test\\resources\\OrderStatus.xlsx");
		wb.write(fos);
		fos.close();*/
	}

	@Step
	public void readAction() throws EncryptedDocumentException, InvalidFormatException, IOException {
		FileInputStream fisFirst=new FileInputStream("..\\EshopTools\\src\\test\\resources\\OrderStatus.xlsx");
		@SuppressWarnings("resource")
		XSSFWorkbook wb= new XSSFWorkbook(fisFirst);
		XSSFSheet sheet=wb.getSheet("Sheet1");
		int rowcount=sheet.getLastRowNum();
		System.out.println("Total number of orders: "+rowcount);
		for(int i=1; i<=rowcount;i++) {
			sheet.getRow(i).getCell(0).setCellType(Cell.CELL_TYPE_STRING);
			String orderNumber=sheet.getRow(i).getCell(0).getStringCellValue();
			//			sheet.getRow(i).getCell(1).setCellType(Cell.CELL_TYPE_STRING);
			//			String status=sheet.getRow(i).getCell(1).getStringCellValue();
			sheet.getRow(i).getCell(2).setCellType(Cell.CELL_TYPE_STRING);
			String action=sheet.getRow(i).getCell(2).getStringCellValue();
			sheet.getRow(i).getCell(3).setCellType(Cell.CELL_TYPE_STRING);
			String execute=sheet.getRow(i).getCell(3).getStringCellValue();
			if(execute.equals("Y")) {
				performAction(orderNumber,action,i);
			}

		}
		fisFirst.close();
		/*		FileOutputStream fos=new FileOutputStream("..\\EshopTools\\src\\test\\resources\\OrderStatus.xlsx");
		wb.write(fos);
		fos.close();*/
	}

	private void performAction(String orderNum,String Action, int rowNum) throws EncryptedDocumentException, InvalidFormatException, IOException {
		String currentDuedateForCalculation;
		String calculatedNewDate;
		switch(Action){    
		case "VACSUS":    
			System.out.println("The order number for Vacation Suspend is: "+orderNum);     
			currentDuedateForCalculation=getCurrentDuedate(orderNum,rowNum);
			calculatedNewDate=getCalculatedNewDate(currentDuedateForCalculation);
			Serenity.setSessionVariable("orderNum").to(orderNum);
			Serenity.setSessionVariable("calculatedNewDate").to(calculatedNewDate);
			return; 
		case "AddPOTSTOHSI":    
			System.out.println("The order number for AddPOTSTOHSI is: "+orderNum);     
			currentDuedateForCalculation=getCurrentDuedate(orderNum,rowNum);
			calculatedNewDate=getCalculatedNewDate(currentDuedateForCalculation);
			Serenity.setSessionVariable("orderNum").to(orderNum);
			Serenity.setSessionVariable("calculatedNewDate").to(calculatedNewDate);
			return; 
		case "DISCONNECT":    
			System.out.println("The order number for DISCONNECT is: "+orderNum);     
			currentDuedateForCalculation=getCurrentDuedate(orderNum,rowNum);
			calculatedNewDate=getCalculatedNewDate(currentDuedateForCalculation);
			Serenity.setSessionVariable("orderNum").to(orderNum);
			Serenity.setSessionVariable("calculatedNewDate").to(calculatedNewDate);
			return; 
		default:     
			System.out.println("NO ACTION DEFINED");;  
		}    

	}



	private String getCalculatedNewDate(String currentDuedateForCalculation) {
		String year=currentDuedateForCalculation.split("-")[0];
		String month=currentDuedateForCalculation.split("-")[1];
		String date=currentDuedateForCalculation.split("-")[2];
		int newdateInteger=Integer.parseInt(date)+2;
		String newdate=String.valueOf(newdateInteger);
		String CalculatedNewDate=year+"-"+month+"-"+newdate;
		return CalculatedNewDate;
	}

	@SuppressWarnings({ "deprecation", "resource" })
	private String getCurrentDuedate(String orderNum, int rowNum) throws IOException {

		FileInputStream fis=new FileInputStream("..\\EshopTools\\src\\test\\resources\\OrderStatus.xlsx");
		@SuppressWarnings("resource")
		XSSFWorkbook wb= new XSSFWorkbook(fis);
		XSSFSheet sheet=wb.getSheet("Sheet1");
		XSSFCell cell=sheet.getRow(rowNum).getCell(0);
		cell.setCellType(Cell.CELL_TYPE_STRING);
		String env = null;
		String CurrentEnvID = null;
		env = Page.currentEnvironment.getKey();
		if (env.equals("TEST4")) {
			CurrentEnvID="4";
		} 
		else if(env.equals("TEST1")) {
			CurrentEnvID="1";
		}
		else if(env.equals("TEST2")) {
			CurrentEnvID="2";
		}
		MongoClient mongoClient = null;
		String dbURI = null;
		dbURI = "mongodb://BMP_rep:BMP_rep_ctl123@vlmddmong01.dev.intranet:26000";
		mongoClient = new MongoClient(new MongoClientURI(dbURI)); 
		DB db = mongoClient.getDB("BMP_ORDERMGMT_"+CurrentEnvID);
		DBCollection tableDetails = db.getCollection("customerOrder");
		BasicDBObject queryDetails = new BasicDBObject();
		BasicDBObject queryDetailsNew = new BasicDBObject();
		queryDetails.put("customerOrderNo", orderNum);
		queryDetailsNew.put("siteOrders.orderDocument.schedule.dates.finalDueDate",1);
		queryDetailsNew.put("_id",0);
		DBCursor cursorDetails =tableDetails.find(queryDetails,queryDetailsNew);


		JSONObject json = new JSONObject(cursorDetails.iterator().next().toString());
		JSONArray siteOrders = json.getJSONArray("siteOrders");
		JSONObject serviceAddressDetails = siteOrders.getJSONObject(0);
		JSONObject serviceAddress = serviceAddressDetails.getJSONObject("orderDocument");
		//         Map<String, Object> serviceAddressMap = serviceAddress.getJSONObject("schedule").toMap();
		JSONObject schedule=serviceAddress.getJSONObject("schedule");
		JSONObject dates=schedule.getJSONObject("dates");
		Object getfinalDueDate=dates.get("finalDueDate");
		String finalDueDate=getfinalDueDate.toString().split("T")[0];
		XSSFCell cell3=sheet.getRow(rowNum).createCell(3);
		cell3.setCellType(Cell.CELL_TYPE_STRING);
		cell3.setCellValue("EXECUTED");
		XSSFCell cell2=sheet.getRow(rowNum).createCell(5);
		cell2.setCellType(Cell.CELL_TYPE_STRING);
		cell2.setCellValue(finalDueDate);
		System.out.println("FinalDueDate populated is: "+finalDueDate);
		fis.close();
		FileOutputStream fos=new FileOutputStream("..\\EshopTools\\src\\test\\resources\\OrderStatus.xlsx");
		wb.write(fos);
		fos.close();
		return finalDueDate;
	}

	@SuppressWarnings("deprecation")
	public void initOrderVacSus(Object orderNumReceived, Object calculatedNewDateReceived) {
		int newDateInteger;
		int dateInteger=Integer.parseInt(calculatedNewDateReceived.toString().split("-")[2]);
		Assert.assertNotNull("Order details are NOT available in Excel file for this test run", orderNumReceived);
		String orderNum=orderNumReceived.toString();
		String calculatedNewDate=calculatedNewDateReceived.toString();

		System.out.println("Received following details for VacSus: OrderNum: "+orderNum+" Calculated New Due Date: "+calculatedNewDate);
	}

	public void validateOrderStatusInSFC() {
		System.out.println("Validating order status in SFC");
		
	}
}

