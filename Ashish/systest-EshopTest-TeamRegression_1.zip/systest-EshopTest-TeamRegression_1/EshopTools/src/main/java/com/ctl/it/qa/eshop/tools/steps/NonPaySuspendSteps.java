package com.ctl.it.qa.eshop.tools.steps;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.junit.Assert;

import com.ctl.it.qa.eshop.tools.pages.NonpaySuspendPage;

import com.ctl.it.qa.eshop.tools.pages.VacationSuspendPage;
import com.ctl.it.qa.staf.Steps;

import net.thucydides.core.annotations.Step;

@SuppressWarnings("serial")
public class NonPaySuspendSteps extends Steps {

	private final Logger slf4jLogger = LoggerFactory.getLogger(VacationSuspendSteps.class);
	NonpaySuspendPage nonpaySuspendPage;

	/**
	 * Method to select Nonpay Suspend Service option
	 */
	public void select_NonpaySuspend_Service() {
		WebDriverWait wait = new WebDriverWait(getDriver(), 100);
		wait.until(ExpectedConditions.visibilityOf(NonpaySuspendPage.btn_Suspend_All));
		NonpaySuspendPage.btn_Suspend_All.click();
		//NonpaySuspendPage.btn_Submit_NonpaySuspend.click();

		slf4jLogger.info("-----------Nonpay Suspend Service Selcted--------------------");
	}
	/**
	 * Method to click  Nonpay Suspend Service update  option
	 */
	

		public void select_NonpaySuspend_Submit_Update() {
			WebDriverWait wait = new WebDriverWait(getDriver(), 100);
			wait.until(ExpectedConditions.visibilityOf(NonpaySuspendPage.btn_Nonpay_Suspend_Submit_Updates));
			
			NonpaySuspendPage.btn_Nonpay_Suspend_Submit_Updates.click();

			slf4jLogger.info("-----------Nonpay Suspend Service submit updates button clicked--------------------");
		}
		
		
		/**
		 * Method to click  Nonpay Suspend Service update  option
		 */
		

			public void select_NonpaySuspend_Submit_button() {
				WebDriverWait wait = new WebDriverWait(getDriver(), 100);
				wait.until(ExpectedConditions.visibilityOf(NonpaySuspendPage.btn_Submit_NonpaySuspend));
				
				NonpaySuspendPage.btn_Submit_NonpaySuspend.click();

				slf4jLogger.info("-----------Nonpay Suspend Service submit updates button clicked--------------------");
			}
}
