package com.ctl.it.qa.eshop.tools.steps;

import org.openqa.selenium.JavascriptExecutor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ctl.it.qa.eshop.tools.pages.LoginPage;
import com.ctl.it.qa.staf.Steps;
import com.ctl.it.qa.staf.xml.reader.IntDataContainer;

import net.thucydides.core.annotations.Step;

public class LoginSteps extends Steps {

	private final Logger slf4jLogger = LoggerFactory.getLogger(LoginSteps.class);
	LoginPage loginPage;

	@Step
	public void Eshop_url_OpenPage() {
		//sfc-url
		//eshop-url		
		try {
			loginPage.openAt(envData.getFieldValue("eshop-url"));
			loginPage.maximize();
			slf4jLogger.info("Open Eshop application URL: " + envData.getFieldValue("eshop-url") + " successfully");
		} catch (Exception e) {
			slf4jLogger.error("Error opening Eshop application URL: " + envData.getFieldValue("eshop-url") + ": Error: "
					+ e.getMessage());
		}
	}


	@Step
	public void SFC_url_OpenPage() {
		//sfc-url
		//eshop-url		
		try {
			loginPage.openAt(envData.getFieldValue("sfc-url"));
			loginPage.maximize();
			slf4jLogger.info("Open Eshop application URL: " + envData.getFieldValue("eshop-url") + " successfully");
		} catch (Exception e) {
			slf4jLogger.error("Error opening Eshop application URL: " + envData.getFieldValue("eshop-url") + ": Error: "
					+ e.getMessage());
		}
	}


	@Step
	public void loginToEshop() {

		enterCredentials("Valid");
		slf4jLogger.info("Entered credentials successfully");
	}

	@Step
	public void Sfc_url_OpenPage() {

		try {
			loginPage.openAt(envData.getFieldValue("sfc-url"));
			loginPage.maximize();
			slf4jLogger.info("Open SFC application URL: " + envData.getFieldValue("sfc-url") + " successfully");
		} catch (Exception e) {
			slf4jLogger.error("Error opening SFC application URL: " + envData.getFieldValue("sfc-url") + ": Error: "
					+ e.getMessage());
		}
	}

	@Step
	public void enterCredentials(String userType) {
		IntDataContainer dataContainer = envData.getContainer("EshopLoginPage").getContainer(userType);
		/*		loginPage.userName.sendKeys(dataContainer.getFieldValue("tbx_username"));		
		loginPage.password.sendKeys(dataContainer.getFieldValue("tbx_password"));
		loginPage.loginBtn.click();*/


		// Login for Azure Migration 
		waitABit(2000);
		loginPage.userNameA.sendKeys(dataContainer.getFieldValue("tbx_username"));
		loginPage.NextA.click();
		waitABit(3000);
		loginPage.passwordA.sendKeys(dataContainer.getFieldValue("tbx_password"));
		loginPage.signInA.click();
		waitABit(2000);
		loginPage.yesA.click();
		slf4jLogger.info("Clicked on login button ");
	}


	public void cleanOpenAccounts() {
		waitABit(30000);
		JavascriptExecutor js2 = (JavascriptExecutor) getDriver();
		js2.executeScript("(() => {\r\n" + 
				"const UNSUPPORTED_IN_UTILITY_BAR_NAME = \"getEnclosingTabId\";\r\n" + 
				"const UTILITY_BAR_GET_TAB_ID = \"getFocusedTabInfo\";\r\n" + 
				"const callMethod = ({ name, apiType, parametersObject }) => {\r\n" + 
				"return new Promise((resolve, reject) => {\r\n" + 
				"const getCallback = responseHandler => {\r\n" + 
				"return (err, response) => {\r\n" + 
				"if (err) return reject(err);\r\n" + 
				"if (typeof responseHandler !== \"function\") return resolve(response);\r\n" + 
				"resolve(responseHandler(response));\r\n" + 
				"};\r\n" + 
				"};\r\n" + 
				"let callback = getCallback();\r\n" + 
				"if (name === UNSUPPORTED_IN_UTILITY_BAR_NAME) {\r\n" + 
				"name = UTILITY_BAR_GET_TAB_ID;\r\n" + 
				"callback = getCallback(response => response.tabId);\r\n" + 
				"}\r\n" + 
				"document.dispatchEvent(\r\n" + 
				"new CustomEvent(\"fireconsoleaction\", {\r\n" + 
				"detail: {\r\n" + 
				"action: {\r\n" + 
				"apiType: apiType,\r\n" + 
				"name: name,\r\n" + 
				"parametersObject: parametersObject,\r\n" + 
				"callback: callback\r\n" + 
				"}\r\n" + 
				"}\r\n" + 
				"})\r\n" + 
				");\r\n" + 
				"});\r\n" + 
				"};\r\n" + 
				"const addEventHandler = ({ eventName, onEvent }) => {\r\n" + 
				"document.dispatchEvent(\r\n" + 
				"new CustomEvent(\"addconsoleeventhandler\", {\r\n" + 
				"detail: {\r\n" + 
				"handler: {\r\n" + 
				"eventName: eventName,\r\n" + 
				"onEvent: onEvent\r\n" + 
				"}\r\n" + 
				"}\r\n" + 
				"})\r\n" + 
				");\r\n" + 
				"};\r\n" + 
				"callMethod({\r\n" + 
				"name: \"getAllTabInfo\",\r\n" + 
				"apiType: \"workspace\"\r\n" + 
				"}).then(allTabs => {\r\n" + 
				"allTabs\r\n" + 
				".forEach(unableToLoadTab => {\r\n" + 
				"const { tabId, subtabs } = unableToLoadTab;\r\n" + 
				"subtabs.forEach(subtab => {\r\n" + 
				"const { tabId } = subtab;\r\n" + 
				"callMethod({\r\n" + 
				"name: \"disableTabClose\",\r\n" + 
				"apiType: \"workspace\",\r\n" + 
				"parametersObject: {\r\n" + 
				"tabId,\r\n" + 
				"disabled: false\r\n" + 
				"}\r\n" + 
				"})\r\n" + 
				".then(success => {\r\n" + 
				"return callMethod({\r\n" + 
				"name: \"closeTab\",\r\n" + 
				"apiType: \"workspace\",\r\n" + 
				"parametersObject: {\r\n" + 
				"tabId\r\n" + 
				"}\r\n" + 
				"});\r\n" + 
				"})\r\n" + 
				".catch(err => {\r\n" + 
				"console.log(err);\r\n" + 
				"});\r\n" + 
				"});\r\n" + 
				"callMethod({\r\n" + 
				"name: \"disableTabClose\",\r\n" + 
				"apiType: \"workspace\",\r\n" + 
				"parametersObject: {\r\n" + 
				"tabId,\r\n" + 
				"disabled: false\r\n" + 
				"}\r\n" + 
				"})\r\n" + 
				".then(success => {\r\n" + 
				"return callMethod({\r\n" + 
				"name: \"closeTab\",\r\n" + 
				"apiType: \"workspace\",\r\n" + 
				"parametersObject: {\r\n" + 
				"tabId\r\n" + 
				"}\r\n" + 
				"});\r\n" + 
				"})\r\n" + 
				".catch(err => {\r\n" + 
				"console.log(err);\r\n" + 
				"});\r\n" + 
				"});\r\n" + 
				"});\r\n" + 
				"})();\r\n" + 
				"");
		waitABit(10000);
		js2.executeScript("(() => {\r\n" + 
				"const UNSUPPORTED_IN_UTILITY_BAR_NAME = \"getEnclosingTabId\";\r\n" + 
				"const UTILITY_BAR_GET_TAB_ID = \"getFocusedTabInfo\";\r\n" + 
				"const callMethod = ({ name, apiType, parametersObject }) => {\r\n" + 
				"return new Promise((resolve, reject) => {\r\n" + 
				"const getCallback = responseHandler => {\r\n" + 
				"return (err, response) => {\r\n" + 
				"if (err) return reject(err);\r\n" + 
				"if (typeof responseHandler !== \"function\") return resolve(response);\r\n" + 
				"resolve(responseHandler(response));\r\n" + 
				"};\r\n" + 
				"};\r\n" + 
				"let callback = getCallback();\r\n" + 
				"if (name === UNSUPPORTED_IN_UTILITY_BAR_NAME) {\r\n" + 
				"name = UTILITY_BAR_GET_TAB_ID;\r\n" + 
				"callback = getCallback(response => response.tabId);\r\n" + 
				"}\r\n" + 
				"document.dispatchEvent(\r\n" + 
				"new CustomEvent(\"fireconsoleaction\", {\r\n" + 
				"detail: {\r\n" + 
				"action: {\r\n" + 
				"apiType: apiType,\r\n" + 
				"name: name,\r\n" + 
				"parametersObject: parametersObject,\r\n" + 
				"callback: callback\r\n" + 
				"}\r\n" + 
				"}\r\n" + 
				"})\r\n" + 
				");\r\n" + 
				"});\r\n" + 
				"};\r\n" + 
				"const addEventHandler = ({ eventName, onEvent }) => {\r\n" + 
				"document.dispatchEvent(\r\n" + 
				"new CustomEvent(\"addconsoleeventhandler\", {\r\n" + 
				"detail: {\r\n" + 
				"handler: {\r\n" + 
				"eventName: eventName,\r\n" + 
				"onEvent: onEvent\r\n" + 
				"}\r\n" + 
				"}\r\n" + 
				"})\r\n" + 
				");\r\n" + 
				"};\r\n" + 
				"callMethod({\r\n" + 
				"name: \"getAllTabInfo\",\r\n" + 
				"apiType: \"workspace\"\r\n" + 
				"}).then(allTabs => {\r\n" + 
				"allTabs\r\n" + 
				".forEach(unableToLoadTab => {\r\n" + 
				"const { tabId, subtabs } = unableToLoadTab;\r\n" + 
				"subtabs.forEach(subtab => {\r\n" + 
				"const { tabId } = subtab;\r\n" + 
				"callMethod({\r\n" + 
				"name: \"disableTabClose\",\r\n" + 
				"apiType: \"workspace\",\r\n" + 
				"parametersObject: {\r\n" + 
				"tabId,\r\n" + 
				"disabled: false\r\n" + 
				"}\r\n" + 
				"})\r\n" + 
				".then(success => {\r\n" + 
				"return callMethod({\r\n" + 
				"name: \"closeTab\",\r\n" + 
				"apiType: \"workspace\",\r\n" + 
				"parametersObject: {\r\n" + 
				"tabId\r\n" + 
				"}\r\n" + 
				"});\r\n" + 
				"})\r\n" + 
				".catch(err => {\r\n" + 
				"console.log(err);\r\n" + 
				"});\r\n" + 
				"});\r\n" + 
				"callMethod({\r\n" + 
				"name: \"disableTabClose\",\r\n" + 
				"apiType: \"workspace\",\r\n" + 
				"parametersObject: {\r\n" + 
				"tabId,\r\n" + 
				"disabled: false\r\n" + 
				"}\r\n" + 
				"})\r\n" + 
				".then(success => {\r\n" + 
				"return callMethod({\r\n" + 
				"name: \"closeTab\",\r\n" + 
				"apiType: \"workspace\",\r\n" + 
				"parametersObject: {\r\n" + 
				"tabId\r\n" + 
				"}\r\n" + 
				"});\r\n" + 
				"})\r\n" + 
				".catch(err => {\r\n" + 
				"console.log(err);\r\n" + 
				"});\r\n" + 
				"});\r\n" + 
				"});\r\n" + 
				"})();\r\n" + 
				"");
	}
}
